//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Ck87hoaG.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/liked",
			"/search",
			"/api/cover",
			"/genre/$genre",
			"/playlist/$playlistId",
			"/api/stream/$trackId"
		],
		preloads: ["/assets/index-rYWbgv8l.js", "/assets/skeleton-BGi-gfMi.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-rYWbgv8l.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D62fdYYA.js"]
	},
	"/liked": {
		filePath: "/workspace/src/routes/liked.tsx",
		children: void 0,
		preloads: ["/assets/liked-CXmnNaYH.js", "/assets/empty-state-CKu2MC7-.js"]
	},
	"/search": {
		filePath: "/workspace/src/routes/search.tsx",
		children: void 0,
		preloads: ["/assets/search-Bw-ylGv-.js", "/assets/empty-state-CKu2MC7-.js"]
	},
	"/genre/$genre": {
		filePath: "/workspace/src/routes/genre.$genre.tsx",
		children: void 0,
		preloads: ["/assets/genre._genre-hkya0j-y.js", "/assets/empty-state-CKu2MC7-.js"]
	},
	"/playlist/$playlistId": {
		filePath: "/workspace/src/routes/playlist.$playlistId.tsx",
		children: void 0,
		preloads: ["/assets/playlist._playlistId-C68kG56i.js", "/assets/empty-state-CKu2MC7-.js"]
	}
} });
//#endregion
export { tsrStartManifest };
