import { t as GENRES } from "./types-Dxs5O5zb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/audius.server-ByS4xktT.js
function asRecord(value) {
	if (value && typeof value === "object" && !Array.isArray(value)) return value;
	return null;
}
function asString(value) {
	return typeof value === "string" && value.trim() ? value : null;
}
function asNumber(value) {
	return typeof value === "number" && Number.isFinite(value) ? value : 0;
}
function pickArtwork(artwork) {
	const rec = asRecord(artwork);
	if (!rec) return null;
	for (const key of [
		"480x480",
		"1000x1000",
		"150x150"
	]) {
		const url = rec[key];
		if (typeof url === "string" && url.startsWith("http")) return url;
	}
	return null;
}
function mapTrack(raw) {
	const rec = asRecord(raw);
	if (!rec) return null;
	if (rec.is_delete === true || rec.is_available === false) return null;
	if (rec.is_streamable === false || rec.is_stream_gated === true) return null;
	const id = asString(rec.id);
	const title = asString(rec.title);
	if (!id || !title) return null;
	const duration = asNumber(rec.duration);
	if (duration <= 0) return null;
	const user = asRecord(rec.user);
	const artist = asString(user?.name) ?? asString(user?.handle) ?? "Неизвестный исполнитель";
	const artistId = asString(user?.id) ?? asString(rec.user_id) ?? "";
	const warning = rec.parental_warning_type;
	return {
		id,
		title,
		artist,
		artistId,
		artwork: pickArtwork(rec.artwork),
		duration,
		genre: asString(rec.genre),
		mood: asString(rec.mood),
		playCount: asNumber(rec.play_count),
		explicit: Boolean(warning && warning !== "None" && warning !== "none")
	};
}
function mapTracks(raw) {
	if (!Array.isArray(raw)) return [];
	const out = [];
	const seen = /* @__PURE__ */ new Set();
	for (const item of raw) {
		const track = mapTrack(item);
		if (!track || seen.has(track.id)) continue;
		seen.add(track.id);
		out.push(track);
	}
	return out;
}
function mapPlaylist(raw) {
	const rec = asRecord(raw);
	if (!rec || rec.is_delete === true || rec.is_private === true) return null;
	const id = asString(rec.id);
	const name = asString(rec.playlist_name) ?? asString(rec.name);
	if (!id || !name) return null;
	const user = asRecord(rec.user);
	const tracks = mapTracks(rec.tracks);
	return {
		id,
		name,
		artwork: pickArtwork(rec.artwork),
		trackCount: asNumber(rec.track_count) || tracks.length,
		artist: asString(user?.name) ?? asString(user?.handle) ?? "",
		tracks
	};
}
function mapPlaylists(raw) {
	if (!Array.isArray(raw)) return [];
	return raw.map(mapPlaylist).filter((p) => Boolean(p && p.trackCount > 0));
}
var APP_NAME = "volna";
var BASE = "https://api.audius.co/v1";
async function audiusJson(path, params = {}) {
	const url = new URL(`${BASE}${path}`);
	url.searchParams.set("app_name", APP_NAME);
	for (const [key, value] of Object.entries(params)) url.searchParams.set(key, value);
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 12e3);
	try {
		const res = await fetch(url, {
			headers: { Accept: "application/json" },
			signal: ctrl.signal
		});
		if (!res.ok) throw new Error(`Каталог недоступен (${res.status})`);
		return await res.json();
	} finally {
		clearTimeout(timer);
	}
}
function dataOf(payload) {
	return asRecord(payload)?.data ?? payload;
}
async function fetchTrending(limit = 20, genre) {
	const params = {
		limit: String(limit),
		time: "week"
	};
	if (genre) params.genre = genre;
	return mapTracks(dataOf(await audiusJson("/tracks/trending", params)));
}
async function fetchUnderground(limit = 16) {
	return mapTracks(dataOf(await audiusJson("/tracks/trending/underground", { limit: String(limit) })));
}
async function fetchSearch(query, limit = 24) {
	const q = query.trim();
	if (!q) return [];
	return mapTracks(dataOf(await audiusJson("/tracks/search", {
		query: q,
		limit: String(limit)
	})));
}
async function fetchPlaylist(id) {
	const data = dataOf(await audiusJson(`/playlists/${encodeURIComponent(id)}`));
	return mapPlaylist(Array.isArray(data) ? data[0] : data);
}
async function fetchTrendingPlaylists(limit = 10) {
	return mapPlaylists(dataOf(await audiusJson("/playlists/trending", { limit: String(limit) })));
}
async function resolveStreamUrl(trackId) {
	const fallback = `${BASE}/tracks/${encodeURIComponent(trackId)}/stream?app_name=${APP_NAME}`;
	try {
		const rec = asRecord(dataOf(await audiusJson(`/tracks/${encodeURIComponent(trackId)}`)));
		const url = asRecord(rec?.stream)?.url;
		if (typeof url === "string" && url.startsWith("http")) return url;
		if (!mapTrack(rec)) throw new Error("Трек недоступен");
	} catch {}
	return fallback;
}
async function fetchHomeFeed() {
	const featured = GENRES.slice(0, 4);
	const [trending, underground, playlists, ...genreResults] = await Promise.all([
		fetchTrending(20).catch(() => []),
		fetchUnderground(16).catch(() => []),
		fetchTrendingPlaylists(10).catch(() => []),
		...featured.map((g) => fetchTrending(14, g.audius).catch(() => []))
	]);
	return {
		trending,
		underground,
		playlists,
		genres: featured.map((g, i) => ({
			id: g.id,
			label: g.label,
			tracks: genreResults[i] ?? []
		}))
	};
}
//#endregion
export { fetchHomeFeed, fetchPlaylist, fetchSearch, fetchTrending, resolveStreamUrl };
