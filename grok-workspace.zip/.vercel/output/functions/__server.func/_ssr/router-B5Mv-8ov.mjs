import { i as __toESM } from "../_runtime.mjs";
import { i as __exportAll, n as genreById } from "./types-Dxs5O5zb.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { B as notFound, _ as createRootRoute, b as useRouter, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as Slot, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { a as SkipForward, c as Search, d as Play, f as Pause, g as Heart, h as House, i as TriangleAlert, l as Repeat, m as ListMusic, n as VolumeX, o as SkipBack, p as Music2, r as Volume2, s as Shuffle, t as X, u as Repeat1, v as ChevronDown } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { a as Trigger, i as Root3, n as Portal, r as Provider, t as Content2 } from "../_libs/@radix-ui/react-tooltip+[...].mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/skeleton-rUo5p5jK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatTime(seconds) {
	if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
	const total = Math.floor(seconds);
	const h = Math.floor(total / 3600);
	const m = Math.floor(total % 3600 / 60);
	const s = total % 60;
	if (h > 0) return `${h}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
	return `${m}:${s.toString().padStart(2, "0")}`;
}
function formatCount(n) {
	if (!Number.isFinite(n) || n < 0) return "0";
	if (n < 1e3) return String(Math.floor(n));
	if (n < 1e6) {
		const v = n / 1e3;
		return `${v >= 10 ? Math.round(v) : v.toFixed(1).replace(/\.0$/, "")}K`;
	}
	const v = n / 1e6;
	return `${v >= 10 ? Math.round(v) : v.toFixed(1).replace(/\.0$/, "")}M`;
}
function proxied(src) {
	if (src.startsWith("/api/cover")) return src;
	return `/api/cover?u=${encodeURIComponent(src)}`;
}
function Cover({ src, alt, className, sizes = "80px" }) {
	const [failed, setFailed] = (0, import_react.useState)(false);
	if (!src || failed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex items-center justify-center bg-elevated text-muted-foreground", className),
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music2, { className: "size-1/3 max-h-10 min-h-4 opacity-60" })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: proxied(src),
		alt,
		sizes,
		className: cn("object-cover", className),
		onError: () => setFailed(true),
		draggable: false
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-full font-medium transition-colors duration-150 disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90",
			ghost: "text-foreground hover:bg-accent",
			outline: "shadow-[var(--shadow-border)] hover:bg-accent",
			secondary: "bg-secondary text-secondary-foreground hover:bg-accent",
			like: "text-muted-foreground hover:text-like"
		},
		size: {
			default: "h-11 px-5 text-sm",
			sm: "h-9 px-3.5 text-sm",
			lg: "h-12 px-6 text-base",
			icon: "size-11",
			"icon-sm": "size-9",
			"icon-lg": "size-14"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function TooltipProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Provider, {
		delayDuration: 400,
		children
	});
}
function Tooltip({ children, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Root3, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
		asChild: true,
		children
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
		side: "top",
		sideOffset: 8,
		className: "z-80 rounded-md bg-popover px-2 py-1 text-xs text-popover-foreground shadow-[var(--shadow-border)]",
		children: label
	}) })] });
}
var useLikes = create()(persist((set, get) => ({
	ids: [],
	byId: {},
	has: (id) => Boolean(get().byId[id]),
	list: () => {
		const { ids, byId } = get();
		return ids.map((id) => byId[id]).filter(Boolean);
	},
	add: (track) => set((s) => {
		if (s.byId[track.id]) return s;
		return {
			ids: [track.id, ...s.ids],
			byId: {
				...s.byId,
				[track.id]: track
			}
		};
	}),
	remove: (id) => set((s) => {
		if (!s.byId[id]) return s;
		const { [id]: _removed, ...rest } = s.byId;
		return {
			ids: s.ids.filter((x) => x !== id),
			byId: rest
		};
	}),
	toggle: (track) => {
		const liked = get().has(track.id);
		if (liked) get().remove(track.id);
		else get().add(track);
		return !liked;
	}
}), { name: "volna-likes" }));
function LikeButton({ track, className, size = "icon" }) {
	const liked = useLikes((s) => Boolean(s.byId[track.id]));
	const toggle = useLikes((s) => s.toggle);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
		label: liked ? "Убрать из Любимого" : "В Любимое",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "button",
			variant: "ghost",
			size,
			className: cn(liked && "text-like hover:text-like", className),
			"aria-label": liked ? "Убрать из Любимого" : "Добавить в Любимое",
			"aria-pressed": liked,
			onClick: (e) => {
				e.stopPropagation();
				const nowLiked = toggle(track);
				toast(nowLiked ? "Добавлено в Любимое" : "Удалено из Любимого", { duration: 1800 });
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
				className: cn("size-5", liked && "fill-like text-like"),
				strokeWidth: 1.75
			})
		})
	});
}
function shuffleAround(tracks, keepIndex) {
	if (tracks.length < 2) return tracks;
	const current = tracks[keepIndex];
	const rest = tracks.filter((_, i) => i !== keepIndex);
	for (let i = rest.length - 1; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1));
		const a = rest[i];
		const b = rest[j];
		if (a && b) {
			rest[i] = b;
			rest[j] = a;
		}
	}
	return current ? [current, ...rest] : rest;
}
var usePlayer = create()(persist((set, get) => ({
	queue: [],
	index: 0,
	isPlaying: false,
	progress: 0,
	duration: 0,
	volume: .85,
	muted: false,
	shuffle: false,
	repeat: "off",
	expanded: false,
	queueOpen: false,
	current: () => {
		const { queue, index } = get();
		return queue[index] ?? null;
	},
	playList: (tracks, startIndex = 0) => {
		if (!tracks.length) return;
		const bounded = Math.max(0, Math.min(startIndex, tracks.length - 1));
		const shuffled = get().shuffle ? shuffleAround(tracks, bounded) : tracks;
		const index = get().shuffle ? 0 : bounded;
		set({
			queue: shuffled,
			index,
			isPlaying: true,
			progress: 0,
			duration: shuffled[index]?.duration ?? 0
		});
	},
	playNext: (track) => {
		const { queue, index } = get();
		if (queue.findIndex((t) => t.id === track.id) === index) return;
		const next = queue.slice();
		next.splice(index + 1, 0, track);
		set({ queue: next });
	},
	toggle: () => {
		if (!get().current()) return;
		set({ isPlaying: !get().isPlaying });
	},
	pause: () => set({ isPlaying: false }),
	resume: () => {
		if (get().current()) set({ isPlaying: true });
	},
	next: () => {
		const { queue, index, repeat } = get();
		if (!queue.length) return;
		if (repeat === "one") {
			set({
				progress: 0,
				isPlaying: true
			});
			return;
		}
		if (index >= queue.length - 1) {
			if (repeat === "all") set({
				index: 0,
				progress: 0,
				isPlaying: true
			});
			else set({
				isPlaying: false,
				progress: 0
			});
			return;
		}
		set({
			index: index + 1,
			progress: 0,
			isPlaying: true
		});
	},
	prev: () => {
		const { index, progress } = get();
		if (progress > 3 || index === 0) {
			set({ progress: 0 });
			return;
		}
		set({
			index: index - 1,
			progress: 0,
			isPlaying: true
		});
	},
	seek: (seconds) => set({ progress: Math.max(0, seconds) }),
	setProgress: (seconds, duration) => set({
		progress: seconds,
		...typeof duration === "number" ? { duration } : {}
	}),
	setVolume: (v) => set({
		volume: Math.min(1, Math.max(0, v)),
		muted: v === 0
	}),
	toggleMute: () => set({ muted: !get().muted }),
	toggleShuffle: () => {
		const next = !get().shuffle;
		const { queue, index } = get();
		if (next && queue.length > 1) set({
			shuffle: true,
			queue: shuffleAround(queue, index),
			index: 0
		});
		else set({ shuffle: next });
	},
	cycleRepeat: () => {
		const order = [
			"off",
			"all",
			"one"
		];
		set({ repeat: order[(order.indexOf(get().repeat) + 1) % order.length] ?? "off" });
	},
	setExpanded: (v) => set({
		expanded: v,
		queueOpen: v ? get().queueOpen : false
	}),
	setQueueOpen: (v) => set({ queueOpen: v }),
	jumpTo: (index) => {
		if (!get().queue[index]) return;
		set({
			index,
			progress: 0,
			isPlaying: true
		});
	}
}), {
	name: "volna-player",
	partialize: (s) => ({
		queue: s.queue,
		index: s.index,
		volume: s.volume,
		muted: s.muted,
		shuffle: s.shuffle,
		repeat: s.repeat
	})
}));
function Skeleton({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-md bg-foreground/8", className),
		"aria-hidden": true
	});
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/functions-WfwCEHnR.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getHomeFeed = createServerFn({ method: "GET" }).handler(createSsrRpc("fd0befe5149cac4308624dbe4d101a9113c92b2a5d7dd2afb27107ce180a03d3"));
var searchTracks = createServerFn({ method: "GET" }).validator(object({
	query: string(),
	limit: number().int().min(1).max(50).optional()
})).handler(createSsrRpc("e054ee621e9f5dd72d0f06e0eea4dc765a273eecc7e2e948ab338ad14cf629d2"));
var getGenreTracks = createServerFn({ method: "GET" }).validator(object({ genre: string() })).handler(createSsrRpc("ae1b735efbb1fb79655a86145dbf0516f3844af057347ca0e509df8412909a73"));
var getPlaylist = createServerFn({ method: "GET" }).validator(object({ id: string() })).handler(createSsrRpc("00ef0308d78391e3347adc0b8ac5ec15b756e68f32348b7ad16ee589382cbf56"));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-B5Mv-8ov.js
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: error.message || "An unexpected error occurred. Try reloading the page."
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	if (typeof window === "undefined") return () => {};
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	const parentOrigin = resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		if (envelope.data.type === "hello") {
			if (!HelloSchema.safeParse(event.data).success) return;
			announce();
			return;
		}
		if (envelope.data.type === "navigate") {
			const parsed = NavigateSchema.safeParse(event.data);
			if (!parsed.success) return;
			navigate(parsed.data.path);
			queueMicrotask(reportLocation);
			return;
		}
		if (envelope.data.type === "history") {
			const parsed = HistorySchema.safeParse(event.data);
			if (!parsed.success) return;
			if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
			window.history.go(parsed.data.delta);
		}
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function Slider({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
		className: cn("relative flex h-11 w-full touch-none items-center select-none", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
			className: "relative h-1 w-full grow overflow-hidden rounded-full bg-foreground/15",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-primary" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-3 rounded-full bg-primary shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" })]
	});
}
function NowPlaying() {
	const expanded = usePlayer((s) => s.expanded);
	const setExpanded = usePlayer((s) => s.setExpanded);
	const setQueueOpen = usePlayer((s) => s.setQueueOpen);
	const current = usePlayer((s) => s.queue[s.index] ?? null);
	const isPlaying = usePlayer((s) => s.isPlaying);
	const progress = usePlayer((s) => s.progress);
	const duration = usePlayer((s) => s.duration);
	const shuffle = usePlayer((s) => s.shuffle);
	const repeat = usePlayer((s) => s.repeat);
	const toggle = usePlayer((s) => s.toggle);
	const next = usePlayer((s) => s.next);
	const prev = usePlayer((s) => s.prev);
	const seek = usePlayer((s) => s.seek);
	const toggleShuffle = usePlayer((s) => s.toggleShuffle);
	const cycleRepeat = usePlayer((s) => s.cycleRepeat);
	if (!expanded || !current) return null;
	const max = duration > 0 ? duration : current.duration;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-40 flex flex-col bg-background px-5 pt-4 pb-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					"aria-label": "Свернуть",
					onClick: () => setExpanded(false),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-6" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-sm text-muted-foreground",
					children: "Сейчас играет"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					"aria-label": "Очередь",
					onClick: () => setQueueOpen(true),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListMusic, { className: "size-5" })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-md flex-1 flex-col justify-center gap-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cover, {
					src: current.artwork,
					alt: "",
					className: "mx-auto aspect-square w-full max-w-sm rounded-2xl",
					sizes: "400px"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "truncate font-display text-2xl font-medium tracking-tight",
							children: current.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-base text-muted-foreground",
							children: current.artist
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LikeButton, { track: current })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: 0,
					max: max || 1,
					step: .25,
					value: [Math.min(progress, max || 0)],
					onValueChange: ([v]) => seek(v ?? 0)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1 flex justify-between text-xs tabular-nums text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatTime(progress) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatTime(max) })]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": "Перемешать",
							"aria-pressed": shuffle,
							className: cn(shuffle && "text-primary"),
							onClick: toggleShuffle,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon-lg",
							"aria-label": "Предыдущий",
							onClick: prev,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipBack, { className: "size-7 fill-current" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon-lg",
							className: "size-16",
							"aria-label": isPlaying ? "Пауза" : "Играть",
							onClick: toggle,
							children: isPlaying ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-7 fill-current" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-7 fill-current translate-x-0.5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon-lg",
							"aria-label": "Следующий",
							onClick: next,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipForward, { className: "size-7 fill-current" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": "Повтор",
							onClick: cycleRepeat,
							className: cn(repeat !== "off" && "text-primary"),
							children: repeat === "one" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat1, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, { className: "size-5" })
						})
					]
				})
			]
		})]
	});
}
function PlayerBar() {
	const current = usePlayer((s) => s.queue[s.index] ?? null);
	const isPlaying = usePlayer((s) => s.isPlaying);
	const progress = usePlayer((s) => s.progress);
	const duration = usePlayer((s) => s.duration);
	const volume = usePlayer((s) => s.volume);
	const muted = usePlayer((s) => s.muted);
	const shuffle = usePlayer((s) => s.shuffle);
	const repeat = usePlayer((s) => s.repeat);
	const toggle = usePlayer((s) => s.toggle);
	const next = usePlayer((s) => s.next);
	const prev = usePlayer((s) => s.prev);
	const seek = usePlayer((s) => s.seek);
	const setVolume = usePlayer((s) => s.setVolume);
	const toggleMute = usePlayer((s) => s.toggleMute);
	const toggleShuffle = usePlayer((s) => s.toggleShuffle);
	const cycleRepeat = usePlayer((s) => s.cycleRepeat);
	const setExpanded = usePlayer((s) => s.setExpanded);
	const setQueueOpen = usePlayer((s) => s.setQueueOpen);
	if (!current) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "hidden h-16 items-center justify-center border-t border-border bg-card px-4 text-sm text-muted-foreground md:flex",
		children: "Выберите трек, чтобы начать слушать"
	});
	const max = duration > 0 ? duration : current.duration;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-t border-border bg-card/95 backdrop-blur-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-1 md:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full bg-primary",
				style: { width: `${max ? Math.min(100, progress / max * 100) : 0}%` }
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-[1fr_auto] items-center gap-2 px-3 py-2 md:grid-cols-[minmax(0,1.2fr)_minmax(0,1.6fr)_minmax(0,1fr)] md:px-4 md:py-0 md:h-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex min-w-0 items-center gap-3 text-left",
					onClick: () => setExpanded(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cover, {
						src: current.artwork,
						alt: "",
						className: "size-12 rounded-md md:size-14",
						sizes: "56px"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-sm font-medium",
							children: current.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-xs text-muted-foreground",
							children: current.artist
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1 md:flex-col md:justify-center md:py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-center gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden md:inline",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									label: "Перемешать",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon-sm",
										"aria-pressed": shuffle,
										className: cn(shuffle && "text-primary"),
										onClick: toggleShuffle,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, { className: "size-4" })
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
								label: "Предыдущий",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon-sm",
									onClick: prev,
									className: "hidden sm:inline-flex",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipBack, { className: "size-5 fill-current" })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								className: "size-11",
								"aria-label": isPlaying ? "Пауза" : "Играть",
								onClick: toggle,
								children: isPlaying ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-5 fill-current" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5 fill-current translate-x-px" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
								label: "Следующий",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon-sm",
									onClick: next,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipForward, { className: "size-5 fill-current" })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden md:inline",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									label: repeat === "one" ? "Повтор трека" : "Повтор",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon-sm",
										onClick: cycleRepeat,
										className: cn(repeat !== "off" && "text-primary"),
										children: repeat === "one" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat1, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, { className: "size-4" })
									})
								})
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hidden w-full items-center gap-2 md:flex",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-10 text-right text-xs tabular-nums text-muted-foreground",
								children: formatTime(progress)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								min: 0,
								max: max || 1,
								step: .25,
								value: [Math.min(progress, max || 0)],
								onValueChange: ([v]) => seek(v ?? 0)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-10 text-xs tabular-nums text-muted-foreground",
								children: formatTime(max)
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden items-center justify-end gap-1 md:flex",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LikeButton, {
							track: current,
							size: "icon-sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
							label: "Очередь",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon-sm",
								"aria-label": "Очередь",
								onClick: () => setQueueOpen(true),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListMusic, { className: "size-5" })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon-sm",
							"aria-label": muted ? "Включить звук" : "Без звука",
							onClick: toggleMute,
							children: muted || volume === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							className: "w-24",
							min: 0,
							max: 1,
							step: .01,
							value: [muted ? 0 : volume],
							onValueChange: ([v]) => setVolume(v ?? 0)
						})
					]
				})
			]
		})]
	});
}
function PlayerEngine() {
	const audioRef = (0, import_react.useRef)(null);
	const seekLock = (0, import_react.useRef)(false);
	const lastId = (0, import_react.useRef)(null);
	const queue = usePlayer((s) => s.queue);
	const index = usePlayer((s) => s.index);
	const isPlaying = usePlayer((s) => s.isPlaying);
	const volume = usePlayer((s) => s.volume);
	const muted = usePlayer((s) => s.muted);
	const progress = usePlayer((s) => s.progress);
	const setProgress = usePlayer((s) => s.setProgress);
	const pause = usePlayer((s) => s.pause);
	const current = queue[index] ?? null;
	(0, import_react.useEffect)(() => {
		const audio = new Audio();
		audio.preload = "auto";
		audioRef.current = audio;
		const onTime = () => {
			if (seekLock.current) return;
			setProgress(audio.currentTime, audio.duration || void 0);
		};
		const onEnded = () => {
			const state = usePlayer.getState();
			if (state.repeat === "one") {
				audio.currentTime = 0;
				audio.play().catch(() => state.pause());
				return;
			}
			state.next();
		};
		const onError = () => pause();
		audio.addEventListener("timeupdate", onTime);
		audio.addEventListener("ended", onEnded);
		audio.addEventListener("error", onError);
		audio.addEventListener("loadedmetadata", onTime);
		return () => {
			audio.pause();
			audio.removeEventListener("timeupdate", onTime);
			audio.removeEventListener("ended", onEnded);
			audio.removeEventListener("error", onError);
			audio.removeEventListener("loadedmetadata", onTime);
			audioRef.current = null;
		};
	}, [pause, setProgress]);
	(0, import_react.useEffect)(() => {
		const audio = audioRef.current;
		if (!audio) return;
		if (!current) {
			audio.pause();
			audio.removeAttribute("src");
			lastId.current = null;
			return;
		}
		if (lastId.current !== current.id) {
			lastId.current = current.id;
			audio.src = `/api/stream/${encodeURIComponent(current.id)}`;
			audio.load();
		}
		audio.volume = muted ? 0 : volume;
		if (isPlaying) audio.play().catch(() => pause());
		else audio.pause();
	}, [
		current,
		isPlaying,
		volume,
		muted,
		pause
	]);
	(0, import_react.useEffect)(() => {
		const audio = audioRef.current;
		if (!audio || !current) return;
		if (Math.abs(audio.currentTime - progress) > 1.25) {
			seekLock.current = true;
			audio.currentTime = progress;
			window.setTimeout(() => {
				seekLock.current = false;
			}, 80);
		}
	}, [progress, current]);
	(0, import_react.useEffect)(() => {
		if (!current || !("mediaSession" in navigator)) return;
		navigator.mediaSession.metadata = new MediaMetadata({
			title: current.title,
			artist: current.artist,
			artwork: current.artwork ? [{
				src: current.artwork,
				sizes: "480x480",
				type: "image/jpeg"
			}] : []
		});
		navigator.mediaSession.playbackState = isPlaying ? "playing" : "paused";
		const store = usePlayer.getState();
		navigator.mediaSession.setActionHandler("play", () => store.resume());
		navigator.mediaSession.setActionHandler("pause", () => store.pause());
		navigator.mediaSession.setActionHandler("previoustrack", () => store.prev());
		navigator.mediaSession.setActionHandler("nexttrack", () => store.next());
		navigator.mediaSession.setActionHandler("seekto", (d) => {
			if (typeof d.seekTime === "number") store.seek(d.seekTime);
		});
	}, [current, isPlaying]);
	return null;
}
function TrackRow({ track, index, queue, showPlays = false }) {
	const playList = usePlayer((s) => s.playList);
	const toggle = usePlayer((s) => s.toggle);
	const current = usePlayer((s) => s.queue[s.index] ?? null);
	const isPlaying = usePlayer((s) => s.isPlaying);
	const active = current?.id === track.id;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		role: "button",
		tabIndex: 0,
		onClick: () => {
			if (active) toggle();
			else playList(queue, index);
		},
		onKeyDown: (e) => {
			if (e.key === "Enter" || e.key === " ") {
				e.preventDefault();
				if (active) toggle();
				else playList(queue, index);
			}
		},
		className: cn("group grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 rounded-xl px-2 py-2", "transition-colors duration-150 hover:bg-accent", active && "bg-accent"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative size-12 shrink-0 overflow-hidden rounded-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cover, {
					src: track.artwork,
					alt: "",
					className: "size-12",
					sizes: "48px"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("absolute inset-0 flex items-center justify-center bg-background/50 opacity-0 transition-opacity duration-150", "group-hover:opacity-100", active && "opacity-100"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						size: "icon-sm",
						className: "size-8 bg-primary text-primary-foreground",
						tabIndex: -1,
						"aria-hidden": true,
						children: active && isPlaying ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-3.5 fill-current" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-3.5 fill-current translate-x-px" })
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("truncate text-sm font-medium", active ? "text-primary" : "text-foreground"),
						children: track.title
					}), track.explicit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-xs bg-foreground/15 px-1 text-xs font-medium leading-4 text-muted-foreground",
						children: "E"
					}) : null]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-sm text-muted-foreground",
					children: track.artist
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1",
				children: [
					showPlays ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden tabular-nums text-xs text-muted-foreground sm:inline",
						children: formatCount(track.playCount)
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LikeButton, {
						track,
						size: "icon-sm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-10 text-right tabular-nums text-xs text-muted-foreground",
						children: formatTime(track.duration)
					})
				]
			})
		]
	});
}
function TrackList({ tracks, showPlays }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-col",
		children: tracks.map((track, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrackRow, {
			track,
			index: i,
			queue: tracks,
			showPlays
		}, track.id))
	});
}
function QueuePanel() {
	const open = usePlayer((s) => s.queueOpen);
	const setQueueOpen = usePlayer((s) => s.setQueueOpen);
	const queue = usePlayer((s) => s.queue);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex justify-end",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute inset-0 bg-background/60",
			"aria-label": "Закрыть очередь",
			onClick: () => setQueueOpen(false)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "relative flex h-full w-full max-w-md flex-col bg-card shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg font-medium",
					children: "Очередь"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon-sm",
					"aria-label": "Закрыть",
					onClick: () => setQueueOpen(false),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 overflow-y-auto px-2 pb-28",
				children: queue.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-3 py-8 text-sm text-muted-foreground",
					children: "Очередь пуста. Запустите любой трек — и здесь появится список."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrackList, { tracks: queue })
			})]
		})]
	});
}
function LogoMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className: cn("text-primary", className),
		"aria-hidden": true,
		fill: "none",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M3 12c2-6 3.5-6 5 0s3.5 6 5 0 3.5-6 5 0 3 6 4 0",
			stroke: "currentColor",
			strokeWidth: "1.8",
			strokeLinecap: "round"
		})
	});
}
function Wordmark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("font-display text-lg font-medium tracking-tight", className),
		children: "Волна"
	});
}
function AppShell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const toggle = usePlayer((s) => s.toggle);
	const next = usePlayer((s) => s.next);
	const prev = usePlayer((s) => s.prev);
	(0, import_react.useEffect)(() => {
		function onKey(e) {
			const tag = e.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA" || e.target?.isContentEditable) return;
			if (e.code === "Space") {
				e.preventDefault();
				toggle();
			} else if (e.code === "ArrowRight" && e.shiftKey) next();
			else if (e.code === "ArrowLeft" && e.shiftKey) prev();
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		toggle,
		next,
		prev
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerEngine, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "sticky top-0 hidden h-dvh w-56 shrink-0 flex-col gap-6 border-r border-border px-4 py-6 md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex items-center gap-2 px-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "size-7" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "flex flex-col gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLink, {
								to: "/",
								label: "Главная",
								icon: House,
								active: pathname === "/"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSideLink, { active: pathname.startsWith("/search") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLink, {
								to: "/liked",
								label: "Любимое",
								icon: Heart,
								active: pathname.startsWith("/liked")
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-auto px-3 text-xs leading-5 text-subtle",
						children: "Оригинальные треки с именами авторов. Без радио-редакций и вырезанных слов."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex-1 px-4 pt-5 pb-36 md:px-8 md:pt-8 md:pb-28",
					children
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "fixed right-0 bottom-0 left-0 z-30 md:left-56",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerBar, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "flex border-t border-border bg-card pb-[env(safe-area-inset-bottom)] md:hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileLink, {
								to: "/",
								label: "Главная",
								icon: House,
								active: pathname === "/"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchMobileLink, { active: pathname.startsWith("/search") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileLink, {
								to: "/liked",
								label: "Любимое",
								icon: Heart,
								active: pathname.startsWith("/liked")
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NowPlaying, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueuePanel, {})
		]
	});
}
function SideLink({ to, label, icon: Icon, active }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: cn("flex h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium transition-colors duration-150", active ? "bg-accent text-foreground" : "text-muted-foreground hover:bg-accent hover:text-foreground"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-5",
			strokeWidth: 1.75
		}), label]
	});
}
function SearchSideLink({ active }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/search",
		search: { q: "" },
		className: cn("flex h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium transition-colors duration-150", active ? "bg-accent text-foreground" : "text-muted-foreground hover:bg-accent hover:text-foreground"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
			className: "size-5",
			strokeWidth: 1.75
		}), "Поиск"]
	});
}
function MobileLink({ to, label, icon: Icon, active }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: cn("flex h-16 flex-1 flex-col items-center justify-center gap-1 text-xs", active ? "text-foreground" : "text-muted-foreground"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-5",
			strokeWidth: 1.75
		}), label]
	});
}
function SearchMobileLink({ active }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/search",
		search: { q: "" },
		className: cn("flex h-16 flex-1 flex-col items-center justify-center gap-1 text-xs", active ? "text-foreground" : "text-muted-foreground"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
			className: "size-5",
			strokeWidth: 1.75
		}), "Поиск"]
	});
}
var styles_default = "/assets/styles-DpxtN1yV.css";
var APP_NAME = "Волна";
var Route$7 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Слушайте музыку в оригинале — без цензуры. Поиск, плеер и Любимое."
			},
			{
				name: "theme-color",
				content: "#0a0a0b"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=Unbounded:wght@500;600&display=swap"
			}
		]
	}),
	component: RootComponent
});
function RootComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "ru",
		className: "dark antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TooltipProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "top-center",
				toastOptions: { className: "bg-popover text-popover-foreground border-border font-sans text-sm" }
			})] }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
var $$splitComponentImporter$4 = () => import("./routes-DONKNbvX.mjs");
var Route$6 = createFileRoute("/")({
	loader: () => getHomeFeed(),
	pendingComponent: HomePending,
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
function HomePending() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-6xl flex-col gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-48 rounded-lg" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-56 w-full rounded-2xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-4",
				children: Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-48 w-36 shrink-0 rounded-xl" }, i))
			})
		]
	});
}
var $$splitComponentImporter$3 = () => import("./liked-DXiqzlMb.mjs");
var Route$5 = createFileRoute("/liked")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./search-rV1E83pw.mjs");
var Route$4 = createFileRoute("/search")({
	validateSearch: (search) => ({ q: typeof search.q === "string" ? search.q : "" }),
	loaderDeps: ({ search }) => ({ q: search.q }),
	loader: async ({ deps }) => {
		const q = deps.q.trim();
		if (q.length < 1) return {
			tracks: [],
			q
		};
		return {
			tracks: await searchTracks({ data: {
				query: q,
				limit: 30
			} }),
			q
		};
	},
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var Route$3 = createFileRoute("/api/cover")({ server: { handlers: { GET: async ({ request }) => {
	const raw = new URL(request.url).searchParams.get("u") ?? "";
	const { fetchArtwork } = await import("./artwork.server-B0WhEpmP.mjs");
	return fetchArtwork(raw);
} } } });
var $$splitComponentImporter$1 = () => import("./genre._genre-Bq3I6MND.mjs");
var Route$2 = createFileRoute("/genre/$genre")({
	loader: async ({ params }) => {
		const meta = genreById(params.genre);
		if (!meta) throw notFound();
		return {
			meta,
			tracks: await getGenreTracks({ data: { genre: params.genre } })
		};
	},
	pendingComponent: GenrePending,
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
function GenrePending() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-3xl flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-40 rounded-lg" }), Array.from({ length: 8 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-16 w-full rounded-xl" }, i))]
	});
}
var $$splitComponentImporter = () => import("./playlist._playlistId-ypOYZPYR.mjs");
var Route$1 = createFileRoute("/playlist/$playlistId")({
	loader: async ({ params }) => {
		const playlist = await getPlaylist({ data: { id: params.playlistId } });
		if (!playlist) throw notFound();
		return { playlist };
	},
	pendingComponent: PlaylistPending,
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
function PlaylistPending() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-3xl flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-48 w-48 rounded-xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-64 rounded-lg" })]
	});
}
async function redirectToStream({ params }) {
	const { resolveStreamUrl } = await import("./audius.server-ByS4xktT.mjs");
	const url = await resolveStreamUrl(params.trackId);
	return new Response(null, {
		status: 302,
		headers: {
			Location: url,
			"Cache-Control": "no-store"
		}
	});
}
var Route = createFileRoute("/api/stream/$trackId")({ server: { handlers: {
	GET: redirectToStream,
	HEAD: redirectToStream
} } });
var rootRouteChildren = {
	IndexRoute: Route$6.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$7
	}),
	LikedRoute: Route$5.update({
		id: "/liked",
		path: "/liked",
		getParentRoute: () => Route$7
	}),
	SearchRoute: Route$4.update({
		id: "/search",
		path: "/search",
		getParentRoute: () => Route$7
	}),
	ApiCoverRoute: Route$3.update({
		id: "/api/cover",
		path: "/api/cover",
		getParentRoute: () => Route$7
	}),
	GenreGenreRoute: Route$2.update({
		id: "/genre/$genre",
		path: "/genre/$genre",
		getParentRoute: () => Route$7
	}),
	PlaylistPlaylistIdRoute: Route$1.update({
		id: "/playlist/$playlistId",
		path: "/playlist/$playlistId",
		getParentRoute: () => Route$7
	}),
	ApiStreamTrackIdRoute: Route.update({
		id: "/api/stream/$trackId",
		path: "/api/stream/$trackId",
		getParentRoute: () => Route$7
	})
};
var routeTree = Route$7._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent,
		scrollRestoration: true,
		defaultPreload: "intent"
	});
}
//#endregion
export { Route$6 as a, Cover as c, cn as d, useLikes as f, Route$4 as i, LikeButton as l, Route$1 as n, TrackList as o, usePlayer as p, Route$2 as r, Button as s, router_exports as t, Skeleton as u };
