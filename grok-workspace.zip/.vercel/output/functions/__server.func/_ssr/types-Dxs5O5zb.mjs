//#region node_modules/.nitro/vite/services/ssr/assets/types-Dxs5O5zb.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var types_exports = /* @__PURE__ */ __exportAll({
	GENRES: () => GENRES,
	genreById: () => genreById
});
var GENRES = [
	{
		id: "electronic",
		label: "Электроника",
		audius: "Electronic"
	},
	{
		id: "house",
		label: "Хаус",
		audius: "House"
	},
	{
		id: "hiphop",
		label: "Хип-хоп",
		audius: "Hip-Hop/Rap"
	},
	{
		id: "pop",
		label: "Поп",
		audius: "Pop"
	},
	{
		id: "rnb",
		label: "R&B",
		audius: "R&B/Soul"
	},
	{
		id: "rock",
		label: "Рок",
		audius: "Rock"
	},
	{
		id: "indie",
		label: "Инди",
		audius: "Indie"
	},
	{
		id: "ambient",
		label: "Эмбиент",
		audius: "Ambient"
	},
	{
		id: "techno",
		label: "Техно",
		audius: "Techno"
	},
	{
		id: "jazz",
		label: "Джаз",
		audius: "Jazz"
	}
];
function genreById(id) {
	return GENRES.find((g) => g.id === id) ?? null;
}
//#endregion
export { __exportAll as i, genreById as n, types_exports as r, GENRES as t };
