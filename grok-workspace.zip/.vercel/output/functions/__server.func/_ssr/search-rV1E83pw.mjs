import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { d as useRouterState, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { c as Search } from "../_libs/lucide-react.mjs";
import { d as cn, i as Route$4, o as TrackList, u as Skeleton } from "./router-B5Mv-8ov.mjs";
import { t as EmptyState } from "./empty-state-CPeYmfHr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/search-rV1E83pw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-full bg-secondary px-4 text-sm text-foreground placeholder:text-subtle", "shadow-[var(--shadow-border)] transition-colors duration-150", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50", className),
		...props
	});
}
function SearchBox({ value, onValueChange, autoFocus, className }) {
	const navigate = useNavigate();
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (autoFocus) ref.current?.focus();
	}, [autoFocus]);
	function submit(e) {
		e.preventDefault();
		const q = value.trim();
		navigate({
			to: "/search",
			search: { q }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: submit,
		className: cn("relative", className),
		role: "search",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-4 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			ref,
			value,
			onChange: (e) => onValueChange(e.target.value),
			placeholder: "Трек, исполнитель или альбом",
			"aria-label": "Поиск музыки",
			className: "pl-11"
		})]
	});
}
function SearchPage() {
	const { tracks, q } = Route$4.useLoaderData();
	const navigate = useNavigate({ from: "/search" });
	const loading = useRouterState({ select: (s) => s.isLoading });
	const [value, setValue] = (0, import_react.useState)(q);
	(0, import_react.useEffect)(() => {
		setValue(q);
	}, [q]);
	(0, import_react.useEffect)(() => {
		const handle = window.setTimeout(() => {
			if (value === q) return;
			navigate({
				search: { q: value },
				replace: true
			});
		}, 380);
		return () => window.clearTimeout(handle);
	}, [
		value,
		q,
		navigate
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-3xl flex-col gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "space-y-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-medium tracking-tight",
				children: "Поиск"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchBox, {
				value,
				onValueChange: setValue,
				autoFocus: true
			})]
		}), loading && q.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-col gap-2",
			children: Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-16 w-full rounded-xl" }, i))
		}) : !q.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "Найдите трек",
			description: "Введите название композиции или имя исполнителя — каталог отдаёт оригиналы без цензуры."
		}) : tracks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "Ничего не нашлось",
			description: `По запросу «${q}» нет доступных треков. Попробуйте другое написание.`
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mb-3 text-sm text-muted-foreground",
			children: [tracks.length, " треков"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrackList, {
			tracks,
			showPlays: true
		})] })]
	});
}
//#endregion
export { SearchPage as component };
