import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { f as useLikes, o as TrackList, s as Button, u as Skeleton } from "./router-B5Mv-8ov.mjs";
import { t as EmptyState } from "./empty-state-CPeYmfHr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/liked-DXiqzlMb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useHydrated() {
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setHydrated(true);
	}, []);
	return hydrated;
}
function LikedPage() {
	const hydrated = useHydrated();
	const tracks = useLikes((s) => s.ids.map((id) => s.byId[id]).filter((t) => Boolean(t)));
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-3xl flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-48 rounded-lg" }), Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-16 w-full rounded-xl" }, i))]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-3xl flex-col gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-medium tracking-tight",
			children: "Любимое"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: tracks.length ? `${tracks.length} ${tracksWord(tracks.length)} — хранятся на этом устройстве` : "Треки, отмеченные сердцем"
		})] }), tracks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "Пока пусто",
			description: "Нажмите сердце на треке — и он появится здесь. Убрать можно тем же сердцем.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					children: "Смотреть каталог"
				})
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrackList, { tracks })]
	});
}
function tracksWord(n) {
	const m = n % 100;
	const d = n % 10;
	if (m > 10 && m < 20) return "треков";
	if (d === 1) return "трек";
	if (d >= 2 && d <= 4) return "трека";
	return "треков";
}
//#endregion
export { LikedPage as component };
