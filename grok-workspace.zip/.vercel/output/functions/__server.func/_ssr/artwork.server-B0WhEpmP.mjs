//#region node_modules/.nitro/vite/services/ssr/assets/artwork.server-B0WhEpmP.js
var FALLBACK_ORIGINS = [
	"https://v.monophonic.digital",
	"https://audius-creator-5.theblueprint.xyz",
	"https://audius-creator-12.theblueprint.xyz",
	"https://audius-content-8.figment.io",
	"https://audius-content-9.figment.io",
	"https://val007.open-audio-validator.com",
	"https://val011.open-audio-validator.com"
];
var PLACEHOLDER = `<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80"><rect fill="#1a1a1e" width="100%" height="100%"/></svg>`;
function isAllowedArtwork(url) {
	if (url.protocol !== "https:") return false;
	if (url.hostname === "localhost" || url.hostname.endsWith(".local")) return false;
	return /^\/content\/[a-zA-Z0-9]+\/\d+x\d+\.(jpg|jpeg|png|webp)$/i.test(url.pathname);
}
async function tryFetch(url) {
	try {
		const res = await fetch(url, {
			signal: AbortSignal.timeout(4500),
			headers: { Accept: "image/*" }
		});
		if (!res.ok) return null;
		const type = res.headers.get("content-type") ?? "";
		if (!type.startsWith("image/") && !type.includes("octet-stream")) return null;
		return res;
	} catch {
		return null;
	}
}
async function fetchArtwork(raw) {
	let parsed;
	try {
		parsed = new URL(raw);
	} catch {
		return svgPlaceholder();
	}
	if (!isAllowedArtwork(parsed)) return svgPlaceholder();
	const origins = [parsed.origin, ...FALLBACK_ORIGINS.filter((o) => o !== parsed.origin)];
	for (const origin of origins) {
		const res = await tryFetch(`${origin}${parsed.pathname}`);
		if (!res) continue;
		return new Response(res.body, { headers: {
			"Content-Type": res.headers.get("content-type") || "image/jpeg",
			"Cache-Control": "public, max-age=86400"
		} });
	}
	return svgPlaceholder();
}
function svgPlaceholder() {
	return new Response(PLACEHOLDER, { headers: {
		"Content-Type": "image/svg+xml",
		"Cache-Control": "public, max-age=300"
	} });
}
//#endregion
export { fetchArtwork };
