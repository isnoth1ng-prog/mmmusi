import { t as GENRES } from "./types-Dxs5O5zb.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as ChevronRight, d as Play, f as Pause } from "../_libs/lucide-react.mjs";
import { a as Route$6, c as Cover, d as cn, l as LikeButton, p as usePlayer, s as Button } from "./router-B5Mv-8ov.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DONKNbvX.js
var import_jsx_runtime = require_jsx_runtime();
function FeaturedHero({ tracks }) {
	const track = tracks[0];
	const playList = usePlayer((s) => s.playList);
	const toggle = usePlayer((s) => s.toggle);
	const current = usePlayer((s) => s.queue[s.index] ?? null);
	const isPlaying = usePlayer((s) => s.isPlaying);
	if (!track) return null;
	const active = current?.id === track.id;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "overflow-hidden rounded-2xl bg-card p-4 shadow-[var(--shadow-border)] sm:p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-5 sm:flex-row sm:items-end",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cover, {
				src: track.artwork,
				alt: "",
				className: "aspect-square w-full max-w-56 rounded-xl sm:w-56",
				sizes: "224px"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
						children: "Сейчас в тренде"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-3xl font-medium tracking-tight sm:text-4xl",
						children: track.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-base text-muted-foreground",
						children: track.artist
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => {
								if (active) toggle();
								else playList(tracks, 0);
							},
							children: [active && isPlaying ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4 fill-current" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 fill-current translate-x-px" }), active && isPlaying ? "Пауза" : "Слушать"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LikeButton, { track })]
					})
				]
			})]
		})
	});
}
function PlaylistCard({ playlist }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/playlist/$playlistId",
		params: { playlistId: playlist.id },
		className: "group w-36 shrink-0 sm:w-40",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-hidden rounded-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cover, {
					src: playlist.artwork,
					alt: "",
					className: "aspect-square w-full",
					sizes: "160px"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 truncate text-sm font-medium",
				children: playlist.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-sm text-muted-foreground",
				children: playlist.artist || `${playlist.trackCount} треков`
			})
		]
	});
}
function TrackCard({ track, index, queue }) {
	const playList = usePlayer((s) => s.playList);
	const toggle = usePlayer((s) => s.toggle);
	const current = usePlayer((s) => s.queue[s.index] ?? null);
	const isPlaying = usePlayer((s) => s.isPlaying);
	const active = current?.id === track.id;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => {
			if (active) toggle();
			else playList(queue, index);
		},
		className: "group w-36 shrink-0 text-left sm:w-40",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative overflow-hidden rounded-xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cover, {
					src: track.artwork,
					alt: "",
					className: "aspect-square w-full",
					sizes: "160px"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("absolute right-2 bottom-2 flex size-11 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-md", "translate-y-2 opacity-0 transition-all duration-200 ease-[cubic-bezier(0.22,1,0.36,1)]", "group-hover:translate-y-0 group-hover:opacity-100", active && "translate-y-0 opacity-100"),
					children: active && isPlaying ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-5 fill-current" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5 fill-current translate-x-px" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-2 truncate text-sm font-medium", active && "text-primary"),
				children: track.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-sm text-muted-foreground",
				children: track.artist
			})
		]
	});
}
function SectionRail({ title, genreId, tracks, children }) {
	if (tracks && tracks.length === 0 && !children) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-end justify-between gap-3",
			children: genreId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/genre/$genre",
				params: { genre: genreId },
				className: "group inline-flex items-center gap-1 text-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg font-medium tracking-tight sm:text-xl",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5 text-muted-foreground transition-transform duration-150 group-hover:translate-x-0.5" })]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg font-medium tracking-tight sm:text-xl",
				children: title
			})
		}), tracks ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex gap-4 overflow-x-auto pb-1 no-scrollbar",
			children: tracks.map((track, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrackCard, {
				track,
				index: i,
				queue: tracks
			}, track.id))
		}) : children]
	});
}
function Home() {
	const feed = Route$6.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-6xl flex-col gap-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Музыкальный сервис"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl font-medium tracking-tight sm:text-4xl",
						children: "Волна"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-xl text-sm text-muted-foreground sm:text-base",
						children: "Полные треки с настоящими именами авторов — без вырезанных слов и радио-версий."
					})
				]
			}),
			feed.trending.length === 0 && feed.underground.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-2xl bg-card px-5 py-8 text-sm text-muted-foreground shadow-[var(--shadow-border)]",
				children: "Каталог сейчас недоступен. Обновите страницу через минуту."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeaturedHero, { tracks: feed.trending }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto no-scrollbar",
				children: GENRES.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/genre/$genre",
					params: { genre: g.id },
					className: "h-9 shrink-0 rounded-full bg-secondary px-4 text-sm leading-9 text-secondary-foreground hover:bg-accent",
					children: g.label
				}, g.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionRail, {
				title: "В тренде",
				tracks: feed.trending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionRail, {
				title: "Новые имена",
				tracks: feed.underground
			}),
			feed.playlists.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionRail, {
				title: "Подборки",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-4 overflow-x-auto pb-1 no-scrollbar",
					children: feed.playlists.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlaylistCard, { playlist: p }, p.id))
				})
			}) : null,
			feed.genres.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionRail, {
				title: g.label,
				genreId: g.id,
				tracks: g.tracks
			}, g.id))
		]
	});
}
//#endregion
export { Home as component };
