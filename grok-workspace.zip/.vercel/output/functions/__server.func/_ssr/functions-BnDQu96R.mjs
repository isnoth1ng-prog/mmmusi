import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { i as string, n as number, r as object } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/functions-BnDQu96R.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getHomeFeed_createServerFn_handler = createServerRpc({
	id: "fd0befe5149cac4308624dbe4d101a9113c92b2a5d7dd2afb27107ce180a03d3",
	name: "getHomeFeed",
	filename: "src/lib/music/functions.ts"
}, (opts) => getHomeFeed.__executeServer(opts));
var getHomeFeed = createServerFn({ method: "GET" }).handler(getHomeFeed_createServerFn_handler, async () => {
	const { fetchHomeFeed } = await import("./audius.server-ByS4xktT.mjs");
	return fetchHomeFeed();
});
var searchTracks_createServerFn_handler = createServerRpc({
	id: "e054ee621e9f5dd72d0f06e0eea4dc765a273eecc7e2e948ab338ad14cf629d2",
	name: "searchTracks",
	filename: "src/lib/music/functions.ts"
}, (opts) => searchTracks.__executeServer(opts));
var searchTracks = createServerFn({ method: "GET" }).validator(object({
	query: string(),
	limit: number().int().min(1).max(50).optional()
})).handler(searchTracks_createServerFn_handler, async ({ data }) => {
	const { fetchSearch } = await import("./audius.server-ByS4xktT.mjs");
	return fetchSearch(data.query, data.limit ?? 24);
});
var getGenreTracks_createServerFn_handler = createServerRpc({
	id: "ae1b735efbb1fb79655a86145dbf0516f3844af057347ca0e509df8412909a73",
	name: "getGenreTracks",
	filename: "src/lib/music/functions.ts"
}, (opts) => getGenreTracks.__executeServer(opts));
var getGenreTracks = createServerFn({ method: "GET" }).validator(object({ genre: string() })).handler(getGenreTracks_createServerFn_handler, async ({ data }) => {
	const { genreById } = await import("./types-Dxs5O5zb.mjs").then((n) => n.r);
	const { fetchTrending } = await import("./audius.server-ByS4xktT.mjs");
	const genre = genreById(data.genre);
	if (!genre) return [];
	return fetchTrending(40, genre.audius);
});
var getPlaylist_createServerFn_handler = createServerRpc({
	id: "00ef0308d78391e3347adc0b8ac5ec15b756e68f32348b7ad16ee589382cbf56",
	name: "getPlaylist",
	filename: "src/lib/music/functions.ts"
}, (opts) => getPlaylist.__executeServer(opts));
var getPlaylist = createServerFn({ method: "GET" }).validator(object({ id: string() })).handler(getPlaylist_createServerFn_handler, async ({ data }) => {
	const { fetchPlaylist } = await import("./audius.server-ByS4xktT.mjs");
	return fetchPlaylist(data.id);
});
//#endregion
export { getGenreTracks_createServerFn_handler, getHomeFeed_createServerFn_handler, getPlaylist_createServerFn_handler, searchTracks_createServerFn_handler };
