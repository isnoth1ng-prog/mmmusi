import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { d as Play } from "../_libs/lucide-react.mjs";
import { c as Cover, n as Route$1, o as TrackList, p as usePlayer, s as Button } from "./router-B5Mv-8ov.mjs";
import { t as EmptyState } from "./empty-state-CPeYmfHr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/playlist._playlistId-ypOYZPYR.js
var import_jsx_runtime = require_jsx_runtime();
function PlaylistPage() {
	const { playlist } = Route$1.useLoaderData();
	const playList = usePlayer((s) => s.playList);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-3xl flex-col gap-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex flex-col gap-5 sm:flex-row sm:items-end",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cover, {
				src: playlist.artwork,
				alt: "",
				className: "aspect-square w-full max-w-48 rounded-xl sm:w-48",
				sizes: "192px"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Подборка"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-3xl font-medium tracking-tight",
						children: playlist.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: [playlist.artist, playlist.trackCount ? ` · ${playlist.trackCount} треков` : ""]
					}),
					playlist.tracks.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "mt-4",
						onClick: () => playList(playlist.tracks, 0),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 fill-current translate-x-px" }), "Слушать"]
					}) : null
				]
			})]
		}), playlist.tracks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "Треки недоступны",
			description: "Эта подборка сейчас без воспроизводимых композиций."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrackList, { tracks: playlist.tracks })]
	});
}
//#endregion
export { PlaylistPage as component };
