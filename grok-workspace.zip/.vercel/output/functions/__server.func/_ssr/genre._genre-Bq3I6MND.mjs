import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { o as TrackList, r as Route$2 } from "./router-B5Mv-8ov.mjs";
import { t as EmptyState } from "./empty-state-CPeYmfHr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/genre._genre-Bq3I6MND.js
var import_jsx_runtime = require_jsx_runtime();
function GenrePage() {
	const { meta, tracks } = Route$2.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-3xl flex-col gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Жанр"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-medium tracking-tight",
			children: meta.label
		})] }), tracks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "Пока тихо",
			description: "В этом жанре сейчас нет доступных треков."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrackList, {
			tracks,
			showPlays: true
		})]
	});
}
//#endregion
export { GenrePage as component };
