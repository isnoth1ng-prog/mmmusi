import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Track } from "@/lib/music/types";

type LikesState = {
  ids: string[];
  byId: Record<string, Track>;
  has: (id: string) => boolean;
  list: () => Track[];
  toggle: (track: Track) => boolean;
  add: (track: Track) => void;
  remove: (id: string) => void;
};

export const useLikes = create<LikesState>()(
  persist(
    (set, get) => ({
      ids: [],
      byId: {},
      has: (id) => Boolean(get().byId[id]),
      list: () => {
        const { ids, byId } = get();
        return ids.map((id) => byId[id]).filter(Boolean);
      },
      add: (track) =>
        set((s) => {
          if (s.byId[track.id]) return s;
          return {
            ids: [track.id, ...s.ids],
            byId: { ...s.byId, [track.id]: track },
          };
        }),
      remove: (id) =>
        set((s) => {
          if (!s.byId[id]) return s;
          const { [id]: _removed, ...rest } = s.byId;
          return { ids: s.ids.filter((x) => x !== id), byId: rest };
        }),
      toggle: (track) => {
        const liked = get().has(track.id);
        if (liked) get().remove(track.id);
        else get().add(track);
        return !liked;
      },
    }),
    { name: "volna-likes" },
  ),
);
