import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Track } from "@/lib/music/types";

export type RepeatMode = "off" | "all" | "one";

type PlayerState = {
  queue: Track[];
  index: number;
  isPlaying: boolean;
  progress: number;
  duration: number;
  volume: number;
  muted: boolean;
  shuffle: boolean;
  repeat: RepeatMode;
  expanded: boolean;
  queueOpen: boolean;
  current: () => Track | null;
  playList: (tracks: Track[], startIndex?: number) => void;
  playNext: (track: Track) => void;
  toggle: () => void;
  pause: () => void;
  resume: () => void;
  next: () => void;
  prev: () => void;
  seek: (seconds: number) => void;
  setProgress: (seconds: number, duration?: number) => void;
  setVolume: (v: number) => void;
  toggleMute: () => void;
  toggleShuffle: () => void;
  cycleRepeat: () => void;
  setExpanded: (v: boolean) => void;
  setQueueOpen: (v: boolean) => void;
  jumpTo: (index: number) => void;
};

function shuffleAround(tracks: Track[], keepIndex: number): Track[] {
  if (tracks.length < 2) return tracks;
  const current = tracks[keepIndex];
  const rest = tracks.filter((_, i) => i !== keepIndex);
  for (let i = rest.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const a = rest[i];
    const b = rest[j];
    if (a && b) {
      rest[i] = b;
      rest[j] = a;
    }
  }
  return current ? [current, ...rest] : rest;
}

export const usePlayer = create<PlayerState>()(
  persist(
    (set, get) => ({
      queue: [],
      index: 0,
      isPlaying: false,
      progress: 0,
      duration: 0,
      volume: 0.85,
      muted: false,
      shuffle: false,
      repeat: "off",
      expanded: false,
      queueOpen: false,
      current: () => {
        const { queue, index } = get();
        return queue[index] ?? null;
      },
      playList: (tracks, startIndex = 0) => {
        if (!tracks.length) return;
        const bounded = Math.max(0, Math.min(startIndex, tracks.length - 1));
        const shuffled = get().shuffle ? shuffleAround(tracks, bounded) : tracks;
        const index = get().shuffle ? 0 : bounded;
        set({
          queue: shuffled,
          index,
          isPlaying: true,
          progress: 0,
          duration: shuffled[index]?.duration ?? 0,
        });
      },
      playNext: (track) => {
        const { queue, index } = get();
        const exists = queue.findIndex((t) => t.id === track.id);
        if (exists === index) return;
        const next = queue.slice();
        next.splice(index + 1, 0, track);
        set({ queue: next });
      },
      toggle: () => {
        if (!get().current()) return;
        set({ isPlaying: !get().isPlaying });
      },
      pause: () => set({ isPlaying: false }),
      resume: () => {
        if (get().current()) set({ isPlaying: true });
      },
      next: () => {
        const { queue, index, repeat } = get();
        if (!queue.length) return;
        if (repeat === "one") {
          set({ progress: 0, isPlaying: true });
          return;
        }
        const last = index >= queue.length - 1;
        if (last) {
          if (repeat === "all") set({ index: 0, progress: 0, isPlaying: true });
          else set({ isPlaying: false, progress: 0 });
          return;
        }
        set({ index: index + 1, progress: 0, isPlaying: true });
      },
      prev: () => {
        const { index, progress } = get();
        if (progress > 3 || index === 0) {
          set({ progress: 0 });
          return;
        }
        set({ index: index - 1, progress: 0, isPlaying: true });
      },
      seek: (seconds) => set({ progress: Math.max(0, seconds) }),
      setProgress: (seconds, duration) =>
        set({
          progress: seconds,
          ...(typeof duration === "number" ? { duration } : {}),
        }),
      setVolume: (v) => set({ volume: Math.min(1, Math.max(0, v)), muted: v === 0 }),
      toggleMute: () => set({ muted: !get().muted }),
      toggleShuffle: () => {
        const next = !get().shuffle;
        const { queue, index } = get();
        if (next && queue.length > 1) {
          set({ shuffle: true, queue: shuffleAround(queue, index), index: 0 });
        } else {
          set({ shuffle: next });
        }
      },
      cycleRepeat: () => {
        const order: RepeatMode[] = ["off", "all", "one"];
        const i = order.indexOf(get().repeat);
        set({ repeat: order[(i + 1) % order.length] ?? "off" });
      },
      setExpanded: (v) => set({ expanded: v, queueOpen: v ? get().queueOpen : false }),
      setQueueOpen: (v) => set({ queueOpen: v }),
      jumpTo: (index) => {
        if (!get().queue[index]) return;
        set({ index, progress: 0, isPlaying: true });
      },
    }),
    {
      name: "volna-player",
      partialize: (s) => ({
        queue: s.queue,
        index: s.index,
        volume: s.volume,
        muted: s.muted,
        shuffle: s.shuffle,
        repeat: s.repeat,
      }),
    },
  ),
);
