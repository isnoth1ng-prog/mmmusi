import type { Playlist, Track } from "./types";

export function asRecord(value: unknown): Record<string, unknown> | null {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    return value as Record<string, unknown>;
  }
  return null;
}

function asString(value: unknown): string | null {
  return typeof value === "string" && value.trim() ? value : null;
}

function asNumber(value: unknown): number {
  return typeof value === "number" && Number.isFinite(value) ? value : 0;
}

function pickArtwork(artwork: unknown): string | null {
  const rec = asRecord(artwork);
  if (!rec) return null;
  for (const key of ["480x480", "1000x1000", "150x150"] as const) {
    const url = rec[key];
    if (typeof url === "string" && url.startsWith("http")) return url;
  }
  return null;
}

export function mapTrack(raw: unknown): Track | null {
  const rec = asRecord(raw);
  if (!rec) return null;
  if (rec.is_delete === true || rec.is_available === false) return null;
  if (rec.is_streamable === false || rec.is_stream_gated === true) return null;
  const id = asString(rec.id);
  const title = asString(rec.title);
  if (!id || !title) return null;
  const duration = asNumber(rec.duration);
  if (duration <= 0) return null;
  const user = asRecord(rec.user);
  const artist =
    asString(user?.name) ?? asString(user?.handle) ?? "Неизвестный исполнитель";
  const artistId = asString(user?.id) ?? asString(rec.user_id) ?? "";
  const warning = rec.parental_warning_type;
  return {
    id,
    title,
    artist,
    artistId,
    artwork: pickArtwork(rec.artwork),
    duration,
    genre: asString(rec.genre),
    mood: asString(rec.mood),
    playCount: asNumber(rec.play_count),
    explicit: Boolean(warning && warning !== "None" && warning !== "none"),
  };
}

export function mapTracks(raw: unknown): Track[] {
  if (!Array.isArray(raw)) return [];
  const out: Track[] = [];
  const seen = new Set<string>();
  for (const item of raw) {
    const track = mapTrack(item);
    if (!track || seen.has(track.id)) continue;
    seen.add(track.id);
    out.push(track);
  }
  return out;
}

export function mapPlaylist(raw: unknown): Playlist | null {
  const rec = asRecord(raw);
  if (!rec || rec.is_delete === true || rec.is_private === true) return null;
  const id = asString(rec.id);
  const name = asString(rec.playlist_name) ?? asString(rec.name);
  if (!id || !name) return null;
  const user = asRecord(rec.user);
  const tracks = mapTracks(rec.tracks);
  return {
    id,
    name,
    artwork: pickArtwork(rec.artwork),
    trackCount: asNumber(rec.track_count) || tracks.length,
    artist: asString(user?.name) ?? asString(user?.handle) ?? "",
    tracks,
  };
}

export function mapPlaylists(raw: unknown): Playlist[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .map(mapPlaylist)
    .filter((p): p is Playlist => Boolean(p && p.trackCount > 0));
}
