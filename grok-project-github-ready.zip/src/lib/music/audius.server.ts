import { GENRES, type HomeFeed, type Playlist, type Track } from "./types";
import { mapPlaylists, mapPlaylist, mapTrack, mapTracks, asRecord } from "./map";

const APP_NAME = "volna";
const BASE = "https://api.audius.co/v1";

async function audiusJson(path: string, params: Record<string, string> = {}) {
  const url = new URL(`${BASE}${path}`);
  url.searchParams.set("app_name", APP_NAME);
  for (const [key, value] of Object.entries(params)) {
    url.searchParams.set(key, value);
  }
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 12000);
  try {
    const res = await fetch(url, {
      headers: { Accept: "application/json" },
      signal: ctrl.signal,
    });
    if (!res.ok) {
      throw new Error(`Каталог недоступен (${res.status})`);
    }
    return (await res.json()) as unknown;
  } finally {
    clearTimeout(timer);
  }
}

function dataOf(payload: unknown): unknown {
  const rec = asRecord(payload);
  return rec?.data ?? payload;
}

export async function fetchTrending(limit = 20, genre?: string): Promise<Track[]> {
  const params: Record<string, string> = { limit: String(limit), time: "week" };
  if (genre) params.genre = genre;
  const payload = await audiusJson("/tracks/trending", params);
  return mapTracks(dataOf(payload));
}

export async function fetchUnderground(limit = 16): Promise<Track[]> {
  const payload = await audiusJson("/tracks/trending/underground", {
    limit: String(limit),
  });
  return mapTracks(dataOf(payload));
}

export async function fetchSearch(query: string, limit = 24): Promise<Track[]> {
  const q = query.trim();
  if (!q) return [];
  const payload = await audiusJson("/tracks/search", {
    query: q,
    limit: String(limit),
  });
  return mapTracks(dataOf(payload));
}

export async function fetchPlaylist(id: string): Promise<Playlist | null> {
  const payload = await audiusJson(`/playlists/${encodeURIComponent(id)}`);
  const data = dataOf(payload);
  const list = Array.isArray(data) ? data[0] : data;
  return mapPlaylist(list);
}

export async function fetchTrendingPlaylists(limit = 10): Promise<Playlist[]> {
  const payload = await audiusJson("/playlists/trending", {
    limit: String(limit),
  });
  return mapPlaylists(dataOf(payload));
}

export async function resolveStreamUrl(trackId: string): Promise<string> {
  const fallback = `${BASE}/tracks/${encodeURIComponent(trackId)}/stream?app_name=${APP_NAME}`;
  try {
    const payload = await audiusJson(`/tracks/${encodeURIComponent(trackId)}`);
    const rec = asRecord(dataOf(payload));
    const stream = asRecord(rec?.stream);
    const url = stream?.url;
    if (typeof url === "string" && url.startsWith("http")) return url;
    const mapped = mapTrack(rec);
    if (!mapped) throw new Error("Трек недоступен");
  } catch {
    // Fall through to the official stream endpoint.
  }
  return fallback;
}

export async function fetchHomeFeed(): Promise<HomeFeed> {
  const featured = GENRES.slice(0, 4);
  const [trending, underground, playlists, ...genreResults] = await Promise.all([
    fetchTrending(20).catch(() => [] as Track[]),
    fetchUnderground(16).catch(() => [] as Track[]),
    fetchTrendingPlaylists(10).catch(() => [] as Playlist[]),
    ...featured.map((g) =>
      fetchTrending(14, g.audius).catch(() => [] as Track[]),
    ),
  ]);

  return {
    trending,
    underground,
    playlists,
    genres: featured.map((g, i) => ({
      id: g.id,
      label: g.label,
      tracks: genreResults[i] ?? [],
    })),
  };
}
