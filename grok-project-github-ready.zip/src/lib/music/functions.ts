import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export const getHomeFeed = createServerFn({ method: "GET" }).handler(async () => {
  const { fetchHomeFeed } = await import("./audius.server");
  return fetchHomeFeed();
});

export const searchTracks = createServerFn({ method: "GET" })
  .validator(
    z.object({
      query: z.string(),
      limit: z.number().int().min(1).max(50).optional(),
    }),
  )
  .handler(async ({ data }) => {
    const { fetchSearch } = await import("./audius.server");
    return fetchSearch(data.query, data.limit ?? 24);
  });

export const getGenreTracks = createServerFn({ method: "GET" })
  .validator(z.object({ genre: z.string() }))
  .handler(async ({ data }) => {
    const { genreById } = await import("./types");
    const { fetchTrending } = await import("./audius.server");
    const genre = genreById(data.genre);
    if (!genre) return [];
    return fetchTrending(40, genre.audius);
  });

export const getPlaylist = createServerFn({ method: "GET" })
  .validator(z.object({ id: z.string() }))
  .handler(async ({ data }) => {
    const { fetchPlaylist } = await import("./audius.server");
    return fetchPlaylist(data.id);
  });
