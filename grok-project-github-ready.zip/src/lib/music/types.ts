export type Track = {
  id: string;
  title: string;
  artist: string;
  artistId: string;
  artwork: string | null;
  duration: number;
  genre: string | null;
  mood: string | null;
  playCount: number;
  explicit: boolean;
};

export type Playlist = {
  id: string;
  name: string;
  artwork: string | null;
  trackCount: number;
  artist: string;
  tracks: Track[];
};

export type HomeFeed = {
  trending: Track[];
  underground: Track[];
  playlists: Playlist[];
  genres: { id: string; label: string; tracks: Track[] }[];
};

export const GENRES = [
  { id: "electronic", label: "Электроника", audius: "Electronic" },
  { id: "house", label: "Хаус", audius: "House" },
  { id: "hiphop", label: "Хип-хоп", audius: "Hip-Hop/Rap" },
  { id: "pop", label: "Поп", audius: "Pop" },
  { id: "rnb", label: "R&B", audius: "R&B/Soul" },
  { id: "rock", label: "Рок", audius: "Rock" },
  { id: "indie", label: "Инди", audius: "Indie" },
  { id: "ambient", label: "Эмбиент", audius: "Ambient" },
  { id: "techno", label: "Техно", audius: "Techno" },
  { id: "jazz", label: "Джаз", audius: "Jazz" },
] as const;

export type GenreId = (typeof GENRES)[number]["id"];

export function genreById(id: string) {
  return GENRES.find((g) => g.id === id) ?? null;
}
