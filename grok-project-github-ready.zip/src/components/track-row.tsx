import { Pause, Play } from "lucide-react";
import { Cover } from "@/components/cover";
import { LikeButton } from "@/components/like-button";
import { Button } from "@/components/ui/button";
import type { Track } from "@/lib/music/types";
import { usePlayer } from "@/lib/player-store";
import { cn, formatCount, formatTime } from "@/lib/utils";

export function TrackRow({
  track,
  index,
  queue,
  showPlays = false,
}: {
  track: Track;
  index: number;
  queue: Track[];
  showPlays?: boolean;
}) {
  const playList = usePlayer((s) => s.playList);
  const toggle = usePlayer((s) => s.toggle);
  const current = usePlayer((s) => s.queue[s.index] ?? null);
  const isPlaying = usePlayer((s) => s.isPlaying);
  const active = current?.id === track.id;

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={() => {
        if (active) toggle();
        else playList(queue, index);
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          if (active) toggle();
          else playList(queue, index);
        }
      }}
      className={cn(
        "group grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 rounded-xl px-2 py-2",
        "transition-colors duration-150 hover:bg-accent",
        active && "bg-accent",
      )}
    >
      <div className="relative size-12 shrink-0 overflow-hidden rounded-md">
        <Cover src={track.artwork} alt="" className="size-12" sizes="48px" />
        <div
          className={cn(
            "absolute inset-0 flex items-center justify-center bg-background/50 opacity-0 transition-opacity duration-150",
            "group-hover:opacity-100",
            active && "opacity-100",
          )}
        >
          <Button
            type="button"
            size="icon-sm"
            className="size-8 bg-primary text-primary-foreground"
            tabIndex={-1}
            aria-hidden
          >
            {active && isPlaying ? (
              <Pause className="size-3.5 fill-current" />
            ) : (
              <Play className="size-3.5 fill-current translate-x-px" />
            )}
          </Button>
        </div>
      </div>
      <div className="min-w-0">
        <div className="flex items-center gap-2">
          <p
            className={cn(
              "truncate text-sm font-medium",
              active ? "text-primary" : "text-foreground",
            )}
          >
            {track.title}
          </p>
          {track.explicit ? (
            <span className="rounded-xs bg-foreground/15 px-1 text-xs font-medium leading-4 text-muted-foreground">
              E
            </span>
          ) : null}
        </div>
        <p className="truncate text-sm text-muted-foreground">{track.artist}</p>
      </div>
      <div className="flex items-center gap-1">
        {showPlays ? (
          <span className="hidden tabular-nums text-xs text-muted-foreground sm:inline">
            {formatCount(track.playCount)}
          </span>
        ) : null}
        <LikeButton track={track} size="icon-sm" />
        <span className="w-10 text-right tabular-nums text-xs text-muted-foreground">
          {formatTime(track.duration)}
        </span>
      </div>
    </div>
  );
}

export function TrackList({
  tracks,
  showPlays,
}: {
  tracks: Track[];
  showPlays?: boolean;
}) {
  return (
    <div className="flex flex-col">
      {tracks.map((track, i) => (
        <TrackRow
          key={track.id}
          track={track}
          index={i}
          queue={tracks}
          showPlays={showPlays}
        />
      ))}
    </div>
  );
}
