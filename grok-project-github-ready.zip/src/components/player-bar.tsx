import {
  ListMusic,
  Pause,
  Play,
  Repeat,
  Repeat1,
  Shuffle,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
} from "lucide-react";
import { Cover } from "@/components/cover";
import { LikeButton } from "@/components/like-button";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Tooltip } from "@/components/ui/tooltip";
import { usePlayer } from "@/lib/player-store";
import { cn, formatTime } from "@/lib/utils";

export function PlayerBar() {
  const current = usePlayer((s) => s.queue[s.index] ?? null);
  const isPlaying = usePlayer((s) => s.isPlaying);
  const progress = usePlayer((s) => s.progress);
  const duration = usePlayer((s) => s.duration);
  const volume = usePlayer((s) => s.volume);
  const muted = usePlayer((s) => s.muted);
  const shuffle = usePlayer((s) => s.shuffle);
  const repeat = usePlayer((s) => s.repeat);
  const toggle = usePlayer((s) => s.toggle);
  const next = usePlayer((s) => s.next);
  const prev = usePlayer((s) => s.prev);
  const seek = usePlayer((s) => s.seek);
  const setVolume = usePlayer((s) => s.setVolume);
  const toggleMute = usePlayer((s) => s.toggleMute);
  const toggleShuffle = usePlayer((s) => s.toggleShuffle);
  const cycleRepeat = usePlayer((s) => s.cycleRepeat);
  const setExpanded = usePlayer((s) => s.setExpanded);
  const setQueueOpen = usePlayer((s) => s.setQueueOpen);

  if (!current) {
    return (
      <div className="hidden h-16 items-center justify-center border-t border-border bg-card px-4 text-sm text-muted-foreground md:flex">
        Выберите трек, чтобы начать слушать
      </div>
    );
  }

  const max = duration > 0 ? duration : current.duration;

  return (
    <div className="border-t border-border bg-card/95 backdrop-blur-sm">
      <div className="h-1 md:hidden">
        <div
          className="h-full bg-primary"
          style={{ width: `${max ? Math.min(100, (progress / max) * 100) : 0}%` }}
        />
      </div>
      <div className="grid grid-cols-[1fr_auto] items-center gap-2 px-3 py-2 md:grid-cols-[minmax(0,1.2fr)_minmax(0,1.6fr)_minmax(0,1fr)] md:px-4 md:py-0 md:h-20">
        <button
          type="button"
          className="flex min-w-0 items-center gap-3 text-left"
          onClick={() => setExpanded(true)}
        >
          <Cover
            src={current.artwork}
            alt=""
            className="size-12 rounded-md md:size-14"
            sizes="56px"
          />
          <span className="min-w-0">
            <span className="block truncate text-sm font-medium">{current.title}</span>
            <span className="block truncate text-xs text-muted-foreground">
              {current.artist}
            </span>
          </span>
        </button>

        <div className="flex items-center gap-1 md:flex-col md:justify-center md:py-2">
          <div className="flex items-center justify-center gap-1">
            <span className="hidden md:inline">
              <Tooltip label="Перемешать">
                <Button
                  variant="ghost"
                  size="icon-sm"
                  aria-pressed={shuffle}
                  className={cn(shuffle && "text-primary")}
                  onClick={toggleShuffle}
                >
                  <Shuffle className="size-4" />
                </Button>
              </Tooltip>
            </span>
            <Tooltip label="Предыдущий">
              <Button variant="ghost" size="icon-sm" onClick={prev} className="hidden sm:inline-flex">
                <SkipBack className="size-5 fill-current" />
              </Button>
            </Tooltip>
            <Button
              size="icon"
              className="size-11"
              aria-label={isPlaying ? "Пауза" : "Играть"}
              onClick={toggle}
            >
              {isPlaying ? (
                <Pause className="size-5 fill-current" />
              ) : (
                <Play className="size-5 fill-current translate-x-px" />
              )}
            </Button>
            <Tooltip label="Следующий">
              <Button variant="ghost" size="icon-sm" onClick={next}>
                <SkipForward className="size-5 fill-current" />
              </Button>
            </Tooltip>
            <span className="hidden md:inline">
              <Tooltip label={repeat === "one" ? "Повтор трека" : "Повтор"}>
                <Button
                  variant="ghost"
                  size="icon-sm"
                  onClick={cycleRepeat}
                  className={cn(repeat !== "off" && "text-primary")}
                >
                  {repeat === "one" ? (
                    <Repeat1 className="size-4" />
                  ) : (
                    <Repeat className="size-4" />
                  )}
                </Button>
              </Tooltip>
            </span>
          </div>
          <div className="hidden w-full items-center gap-2 md:flex">
            <span className="w-10 text-right text-xs tabular-nums text-muted-foreground">
              {formatTime(progress)}
            </span>
            <Slider
              min={0}
              max={max || 1}
              step={0.25}
              value={[Math.min(progress, max || 0)]}
              onValueChange={([v]) => seek(v ?? 0)}
            />
            <span className="w-10 text-xs tabular-nums text-muted-foreground">
              {formatTime(max)}
            </span>
          </div>
        </div>

        <div className="hidden items-center justify-end gap-1 md:flex">
          <LikeButton track={current} size="icon-sm" />
          <Tooltip label="Очередь">
            <Button
              variant="ghost"
              size="icon-sm"
              aria-label="Очередь"
              onClick={() => setQueueOpen(true)}
            >
              <ListMusic className="size-5" />
            </Button>
          </Tooltip>
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label={muted ? "Включить звук" : "Без звука"}
            onClick={toggleMute}
          >
            {muted || volume === 0 ? (
              <VolumeX className="size-5" />
            ) : (
              <Volume2 className="size-5" />
            )}
          </Button>
          <Slider
            className="w-24"
            min={0}
            max={1}
            step={0.01}
            value={[muted ? 0 : volume]}
            onValueChange={([v]) => setVolume(v ?? 0)}
          />
        </div>
      </div>
    </div>
  );
}
