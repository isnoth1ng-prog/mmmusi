import { useNavigate } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { useEffect, useRef, type FormEvent } from "react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export function SearchBox({
  value,
  onValueChange,
  autoFocus,
  className,
}: {
  value: string;
  onValueChange: (v: string) => void;
  autoFocus?: boolean;
  className?: string;
}) {
  const navigate = useNavigate();
  const ref = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (autoFocus) ref.current?.focus();
  }, [autoFocus]);

  function submit(e: FormEvent) {
    e.preventDefault();
    const q = value.trim();
    void navigate({ to: "/search", search: { q } });
  }

  return (
    <form onSubmit={submit} className={cn("relative", className)} role="search">
      <Search className="pointer-events-none absolute top-1/2 left-4 size-4 -translate-y-1/2 text-muted-foreground" />
      <Input
        ref={ref}
        value={value}
        onChange={(e) => onValueChange(e.target.value)}
        placeholder="Трек, исполнитель или альбом"
        aria-label="Поиск музыки"
        className="pl-11"
      />
    </form>
  );
}
