import { Music2 } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

function proxied(src: string) {
  if (src.startsWith("/api/cover")) return src;
  return `/api/cover?u=${encodeURIComponent(src)}`;
}

export function Cover({
  src,
  alt,
  className,
  sizes = "80px",
}: {
  src: string | null;
  alt: string;
  className?: string;
  sizes?: string;
}) {
  const [failed, setFailed] = useState(false);
  if (!src || failed) {
    return (
      <div
        className={cn(
          "flex items-center justify-center bg-elevated text-muted-foreground",
          className,
        )}
        aria-hidden
      >
        <Music2 className="size-1/3 max-h-10 min-h-4 opacity-60" />
      </div>
    );
  }
  return (
    <img
      src={proxied(src)}
      alt={alt}
      sizes={sizes}
      className={cn("object-cover", className)}
      onError={() => setFailed(true)}
      draggable={false}
    />
  );
}
