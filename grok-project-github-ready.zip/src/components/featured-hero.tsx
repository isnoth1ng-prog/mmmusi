import { Pause, Play } from "lucide-react";
import { Cover } from "@/components/cover";
import { LikeButton } from "@/components/like-button";
import { Button } from "@/components/ui/button";
import type { Track } from "@/lib/music/types";
import { usePlayer } from "@/lib/player-store";

export function FeaturedHero({ tracks }: { tracks: Track[] }) {
  const track = tracks[0];
  const playList = usePlayer((s) => s.playList);
  const toggle = usePlayer((s) => s.toggle);
  const current = usePlayer((s) => s.queue[s.index] ?? null);
  const isPlaying = usePlayer((s) => s.isPlaying);
  if (!track) return null;
  const active = current?.id === track.id;

  return (
    <section className="overflow-hidden rounded-2xl bg-card p-4 shadow-[var(--shadow-border)] sm:p-6">
      <div className="flex flex-col gap-5 sm:flex-row sm:items-end">
        <Cover
          src={track.artwork}
          alt=""
          className="aspect-square w-full max-w-56 rounded-xl sm:w-56"
          sizes="224px"
        />
        <div className="min-w-0 flex-1">
          <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">
            Сейчас в тренде
          </p>
          <h2 className="mt-2 font-display text-3xl font-medium tracking-tight sm:text-4xl">
            {track.title}
          </h2>
          <p className="mt-1 text-base text-muted-foreground">{track.artist}</p>
          <div className="mt-5 flex items-center gap-2">
            <Button
              onClick={() => {
                if (active) toggle();
                else playList(tracks, 0);
              }}
            >
              {active && isPlaying ? (
                <Pause className="size-4 fill-current" />
              ) : (
                <Play className="size-4 fill-current translate-x-px" />
              )}
              {active && isPlaying ? "Пауза" : "Слушать"}
            </Button>
            <LikeButton track={track} />
          </div>
        </div>
      </div>
    </section>
  );
}
