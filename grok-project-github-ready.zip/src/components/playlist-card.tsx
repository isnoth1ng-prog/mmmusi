import { Link } from "@tanstack/react-router";
import { Cover } from "@/components/cover";
import type { Playlist } from "@/lib/music/types";

export function PlaylistCard({ playlist }: { playlist: Playlist }) {
  return (
    <Link
      to="/playlist/$playlistId"
      params={{ playlistId: playlist.id }}
      className="group w-36 shrink-0 sm:w-40"
    >
      <div className="overflow-hidden rounded-xl">
        <Cover
          src={playlist.artwork}
          alt=""
          className="aspect-square w-full"
          sizes="160px"
        />
      </div>
      <p className="mt-2 truncate text-sm font-medium">{playlist.name}</p>
      <p className="truncate text-sm text-muted-foreground">
        {playlist.artist || `${playlist.trackCount} треков`}
      </p>
    </Link>
  );
}
