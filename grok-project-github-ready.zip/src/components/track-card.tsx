import { Pause, Play } from "lucide-react";
import { Cover } from "@/components/cover";
import type { Track } from "@/lib/music/types";
import { usePlayer } from "@/lib/player-store";
import { cn } from "@/lib/utils";

export function TrackCard({
  track,
  index,
  queue,
}: {
  track: Track;
  index: number;
  queue: Track[];
}) {
  const playList = usePlayer((s) => s.playList);
  const toggle = usePlayer((s) => s.toggle);
  const current = usePlayer((s) => s.queue[s.index] ?? null);
  const isPlaying = usePlayer((s) => s.isPlaying);
  const active = current?.id === track.id;

  return (
    <button
      type="button"
      onClick={() => {
        if (active) toggle();
        else playList(queue, index);
      }}
      className="group w-36 shrink-0 text-left sm:w-40"
    >
      <div className="relative overflow-hidden rounded-xl">
        <Cover
          src={track.artwork}
          alt=""
          className="aspect-square w-full"
          sizes="160px"
        />
        <div
          className={cn(
            "absolute right-2 bottom-2 flex size-11 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-md",
            "translate-y-2 opacity-0 transition-all duration-200 ease-[cubic-bezier(0.22,1,0.36,1)]",
            "group-hover:translate-y-0 group-hover:opacity-100",
            active && "translate-y-0 opacity-100",
          )}
        >
          {active && isPlaying ? (
            <Pause className="size-5 fill-current" />
          ) : (
            <Play className="size-5 fill-current translate-x-px" />
          )}
        </div>
      </div>
      <p className={cn("mt-2 truncate text-sm font-medium", active && "text-primary")}>
        {track.title}
      </p>
      <p className="truncate text-sm text-muted-foreground">{track.artist}</p>
    </button>
  );
}
