import { Link, useRouterState } from "@tanstack/react-router";
import { Heart, Home, Search, type LucideIcon } from "lucide-react";
import type { ReactNode } from "react";
import { useEffect } from "react";
import { NowPlaying } from "@/components/now-playing";
import { PlayerBar } from "@/components/player-bar";
import { PlayerEngine } from "@/components/player-engine";
import { QueuePanel } from "@/components/queue-panel";
import { LogoMark, Wordmark } from "@/components/logo";
import { usePlayer } from "@/lib/player-store";
import { cn } from "@/lib/utils";

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const toggle = usePlayer((s) => s.toggle);
  const next = usePlayer((s) => s.next);
  const prev = usePlayer((s) => s.prev);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || (e.target as HTMLElement)?.isContentEditable)
        return;
      if (e.code === "Space") {
        e.preventDefault();
        toggle();
      } else if (e.code === "ArrowRight" && e.shiftKey) {
        next();
      } else if (e.code === "ArrowLeft" && e.shiftKey) {
        prev();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [toggle, next, prev]);

  return (
    <div className="flex min-h-dvh bg-background text-foreground">
      <PlayerEngine />
      <aside className="sticky top-0 hidden h-dvh w-56 shrink-0 flex-col gap-6 border-r border-border px-4 py-6 md:flex">
        <Link to="/" className="flex items-center gap-2 px-2">
          <LogoMark className="size-7" />
          <Wordmark />
        </Link>
        <nav className="flex flex-col gap-1">
          <SideLink
            to="/"
            label="Главная"
            icon={Home}
            active={pathname === "/"}
          />
          <SearchSideLink active={pathname.startsWith("/search")} />
          <SideLink
            to="/liked"
            label="Любимое"
            icon={Heart}
            active={pathname.startsWith("/liked")}
          />
        </nav>
        <p className="mt-auto px-3 text-xs leading-5 text-subtle">
          Оригинальные треки с именами авторов. Без радио-редакций и вырезанных слов.
        </p>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <main className="flex-1 px-4 pt-5 pb-36 md:px-8 md:pt-8 md:pb-28">{children}</main>
        <div className="fixed right-0 bottom-0 left-0 z-30 md:left-56">
          <PlayerBar />
          <nav className="flex border-t border-border bg-card pb-[env(safe-area-inset-bottom)] md:hidden">
            <MobileLink to="/" label="Главная" icon={Home} active={pathname === "/"} />
            <SearchMobileLink active={pathname.startsWith("/search")} />
            <MobileLink
              to="/liked"
              label="Любимое"
              icon={Heart}
              active={pathname.startsWith("/liked")}
            />
          </nav>
        </div>
      </div>
      <NowPlaying />
      <QueuePanel />
    </div>
  );
}

function SideLink({
  to,
  label,
  icon: Icon,
  active,
}: {
  to: "/" | "/liked";
  label: string;
  icon: LucideIcon;
  active: boolean;
}) {
  return (
    <Link
      to={to}
      className={cn(
        "flex h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium transition-colors duration-150",
        active
          ? "bg-accent text-foreground"
          : "text-muted-foreground hover:bg-accent hover:text-foreground",
      )}
    >
      <Icon className="size-5" strokeWidth={1.75} />
      {label}
    </Link>
  );
}

function SearchSideLink({ active }: { active: boolean }) {
  return (
    <Link
      to="/search"
      search={{ q: "" }}
      className={cn(
        "flex h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium transition-colors duration-150",
        active
          ? "bg-accent text-foreground"
          : "text-muted-foreground hover:bg-accent hover:text-foreground",
      )}
    >
      <Search className="size-5" strokeWidth={1.75} />
      Поиск
    </Link>
  );
}

function MobileLink({
  to,
  label,
  icon: Icon,
  active,
}: {
  to: "/" | "/liked";
  label: string;
  icon: LucideIcon;
  active: boolean;
}) {
  return (
    <Link
      to={to}
      className={cn(
        "flex h-16 flex-1 flex-col items-center justify-center gap-1 text-xs",
        active ? "text-foreground" : "text-muted-foreground",
      )}
    >
      <Icon className="size-5" strokeWidth={1.75} />
      {label}
    </Link>
  );
}

function SearchMobileLink({ active }: { active: boolean }) {
  return (
    <Link
      to="/search"
      search={{ q: "" }}
      className={cn(
        "flex h-16 flex-1 flex-col items-center justify-center gap-1 text-xs",
        active ? "text-foreground" : "text-muted-foreground",
      )}
    >
      <Search className="size-5" strokeWidth={1.75} />
      Поиск
    </Link>
  );
}
