import {
  ChevronDown,
  ListMusic,
  Pause,
  Play,
  Repeat,
  Repeat1,
  Shuffle,
  SkipBack,
  SkipForward,
} from "lucide-react";
import { Cover } from "@/components/cover";
import { LikeButton } from "@/components/like-button";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { usePlayer } from "@/lib/player-store";
import { cn, formatTime } from "@/lib/utils";

export function NowPlaying() {
  const expanded = usePlayer((s) => s.expanded);
  const setExpanded = usePlayer((s) => s.setExpanded);
  const setQueueOpen = usePlayer((s) => s.setQueueOpen);
  const current = usePlayer((s) => s.queue[s.index] ?? null);
  const isPlaying = usePlayer((s) => s.isPlaying);
  const progress = usePlayer((s) => s.progress);
  const duration = usePlayer((s) => s.duration);
  const shuffle = usePlayer((s) => s.shuffle);
  const repeat = usePlayer((s) => s.repeat);
  const toggle = usePlayer((s) => s.toggle);
  const next = usePlayer((s) => s.next);
  const prev = usePlayer((s) => s.prev);
  const seek = usePlayer((s) => s.seek);
  const toggleShuffle = usePlayer((s) => s.toggleShuffle);
  const cycleRepeat = usePlayer((s) => s.cycleRepeat);

  if (!expanded || !current) return null;

  const max = duration > 0 ? duration : current.duration;

  return (
    <div className="fixed inset-0 z-40 flex flex-col bg-background px-5 pt-4 pb-8">
      <div className="flex items-center justify-between">
        <Button
          variant="ghost"
          size="icon"
          aria-label="Свернуть"
          onClick={() => setExpanded(false)}
        >
          <ChevronDown className="size-6" />
        </Button>
        <p className="font-display text-sm text-muted-foreground">Сейчас играет</p>
        <Button
          variant="ghost"
          size="icon"
          aria-label="Очередь"
          onClick={() => setQueueOpen(true)}
        >
          <ListMusic className="size-5" />
        </Button>
      </div>

      <div className="mx-auto flex w-full max-w-md flex-1 flex-col justify-center gap-8">
        <Cover
          src={current.artwork}
          alt=""
          className="mx-auto aspect-square w-full max-w-sm rounded-2xl"
          sizes="400px"
        />
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h2 className="truncate font-display text-2xl font-medium tracking-tight">
              {current.title}
            </h2>
            <p className="truncate text-base text-muted-foreground">{current.artist}</p>
          </div>
          <LikeButton track={current} />
        </div>

        <div>
          <Slider
            min={0}
            max={max || 1}
            step={0.25}
            value={[Math.min(progress, max || 0)]}
            onValueChange={([v]) => seek(v ?? 0)}
          />
          <div className="mt-1 flex justify-between text-xs tabular-nums text-muted-foreground">
            <span>{formatTime(progress)}</span>
            <span>{formatTime(max)}</span>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <Button
            variant="ghost"
            size="icon"
            aria-label="Перемешать"
            aria-pressed={shuffle}
            className={cn(shuffle && "text-primary")}
            onClick={toggleShuffle}
          >
            <Shuffle className="size-5" />
          </Button>
          <Button variant="ghost" size="icon-lg" aria-label="Предыдущий" onClick={prev}>
            <SkipBack className="size-7 fill-current" />
          </Button>
          <Button
            size="icon-lg"
            className="size-16"
            aria-label={isPlaying ? "Пауза" : "Играть"}
            onClick={toggle}
          >
            {isPlaying ? (
              <Pause className="size-7 fill-current" />
            ) : (
              <Play className="size-7 fill-current translate-x-0.5" />
            )}
          </Button>
          <Button variant="ghost" size="icon-lg" aria-label="Следующий" onClick={next}>
            <SkipForward className="size-7 fill-current" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            aria-label="Повтор"
            onClick={cycleRepeat}
            className={cn(repeat !== "off" && "text-primary")}
          >
            {repeat === "one" ? (
              <Repeat1 className="size-5" />
            ) : (
              <Repeat className="size-5" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
