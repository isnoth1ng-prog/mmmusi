import { X } from "lucide-react";
import { TrackList } from "@/components/track-row";
import { Button } from "@/components/ui/button";
import { usePlayer } from "@/lib/player-store";

export function QueuePanel() {
  const open = usePlayer((s) => s.queueOpen);
  const setQueueOpen = usePlayer((s) => s.setQueueOpen);
  const queue = usePlayer((s) => s.queue);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <button
        type="button"
        className="absolute inset-0 bg-background/60"
        aria-label="Закрыть очередь"
        onClick={() => setQueueOpen(false)}
      />
      <aside className="relative flex h-full w-full max-w-md flex-col bg-card shadow-[var(--shadow-border)]">
        <div className="flex items-center justify-between px-4 py-3">
          <h2 className="font-display text-lg font-medium">Очередь</h2>
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label="Закрыть"
            onClick={() => setQueueOpen(false)}
          >
            <X className="size-5" />
          </Button>
        </div>
        <div className="flex-1 overflow-y-auto px-2 pb-28">
          {queue.length === 0 ? (
            <p className="px-3 py-8 text-sm text-muted-foreground">
              Очередь пуста. Запустите любой трек — и здесь появится список.
            </p>
          ) : (
            <TrackList tracks={queue} />
          )}
        </div>
      </aside>
    </div>
  );
}
