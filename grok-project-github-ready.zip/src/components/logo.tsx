import { cn } from "@/lib/utils";

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      className={cn("text-primary", className)}
      aria-hidden
      fill="none"
    >
      <path
        d="M3 12c2-6 3.5-6 5 0s3.5 6 5 0 3.5-6 5 0 3 6 4 0"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function Wordmark({ className }: { className?: string }) {
  return (
    <span className={cn("font-display text-lg font-medium tracking-tight", className)}>
      Волна
    </span>
  );
}
