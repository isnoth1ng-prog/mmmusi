import { Heart } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Tooltip } from "@/components/ui/tooltip";
import { useLikes } from "@/lib/likes-store";
import type { Track } from "@/lib/music/types";
import { cn } from "@/lib/utils";

export function LikeButton({
  track,
  className,
  size = "icon",
}: {
  track: Track;
  className?: string;
  size?: "icon" | "icon-sm";
}) {
  const liked = useLikes((s) => Boolean(s.byId[track.id]));
  const toggle = useLikes((s) => s.toggle);

  return (
    <Tooltip label={liked ? "Убрать из Любимого" : "В Любимое"}>
      <Button
        type="button"
        variant="ghost"
        size={size}
        className={cn(liked && "text-like hover:text-like", className)}
        aria-label={liked ? "Убрать из Любимого" : "Добавить в Любимое"}
        aria-pressed={liked}
        onClick={(e) => {
          e.stopPropagation();
          const nowLiked = toggle(track);
          toast(nowLiked ? "Добавлено в Любимое" : "Удалено из Любимого", {
            duration: 1800,
          });
        }}
      >
        <Heart
          className={cn("size-5", liked && "fill-like text-like")}
          strokeWidth={1.75}
        />
      </Button>
    </Tooltip>
  );
}
