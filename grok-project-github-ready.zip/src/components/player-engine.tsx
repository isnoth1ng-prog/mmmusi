import { useEffect, useRef } from "react";
import { usePlayer } from "@/lib/player-store";

export function PlayerEngine() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const seekLock = useRef(false);
  const lastId = useRef<string | null>(null);

  const queue = usePlayer((s) => s.queue);
  const index = usePlayer((s) => s.index);
  const isPlaying = usePlayer((s) => s.isPlaying);
  const volume = usePlayer((s) => s.volume);
  const muted = usePlayer((s) => s.muted);
  const progress = usePlayer((s) => s.progress);
  const setProgress = usePlayer((s) => s.setProgress);
  const pause = usePlayer((s) => s.pause);
  const current = queue[index] ?? null;

  useEffect(() => {
    const audio = new Audio();
    audio.preload = "auto";
    audioRef.current = audio;

    const onTime = () => {
      if (seekLock.current) return;
      setProgress(audio.currentTime, audio.duration || undefined);
    };
    const onEnded = () => {
      const state = usePlayer.getState();
      if (state.repeat === "one") {
        audio.currentTime = 0;
        void audio.play().catch(() => state.pause());
        return;
      }
      state.next();
    };
    const onError = () => pause();

    audio.addEventListener("timeupdate", onTime);
    audio.addEventListener("ended", onEnded);
    audio.addEventListener("error", onError);
    audio.addEventListener("loadedmetadata", onTime);

    return () => {
      audio.pause();
      audio.removeEventListener("timeupdate", onTime);
      audio.removeEventListener("ended", onEnded);
      audio.removeEventListener("error", onError);
      audio.removeEventListener("loadedmetadata", onTime);
      audioRef.current = null;
    };
  }, [pause, setProgress]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    if (!current) {
      audio.pause();
      audio.removeAttribute("src");
      lastId.current = null;
      return;
    }
    if (lastId.current !== current.id) {
      lastId.current = current.id;
      audio.src = `/api/stream/${encodeURIComponent(current.id)}`;
      audio.load();
    }
    audio.volume = muted ? 0 : volume;
    if (isPlaying) {
      void audio.play().catch(() => pause());
    } else {
      audio.pause();
    }
  }, [current, isPlaying, volume, muted, pause]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio || !current) return;
    if (Math.abs(audio.currentTime - progress) > 1.25) {
      seekLock.current = true;
      audio.currentTime = progress;
      window.setTimeout(() => {
        seekLock.current = false;
      }, 80);
    }
  }, [progress, current]);

  useEffect(() => {
    if (!current || !("mediaSession" in navigator)) return;
    navigator.mediaSession.metadata = new MediaMetadata({
      title: current.title,
      artist: current.artist,
      artwork: current.artwork
        ? [{ src: current.artwork, sizes: "480x480", type: "image/jpeg" }]
        : [],
    });
    navigator.mediaSession.playbackState = isPlaying ? "playing" : "paused";
    const store = usePlayer.getState();
    navigator.mediaSession.setActionHandler("play", () => store.resume());
    navigator.mediaSession.setActionHandler("pause", () => store.pause());
    navigator.mediaSession.setActionHandler("previoustrack", () => store.prev());
    navigator.mediaSession.setActionHandler("nexttrack", () => store.next());
    navigator.mediaSession.setActionHandler("seekto", (d) => {
      if (typeof d.seekTime === "number") store.seek(d.seekTime);
    });
  }, [current, isPlaying]);

  return null;
}
