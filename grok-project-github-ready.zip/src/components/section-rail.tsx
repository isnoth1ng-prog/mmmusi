import { Link } from "@tanstack/react-router";
import { ChevronRight } from "lucide-react";
import type { ReactNode } from "react";
import { TrackCard } from "@/components/track-card";
import type { Track } from "@/lib/music/types";

export function SectionRail({
  title,
  genreId,
  tracks,
  children,
}: {
  title: string;
  genreId?: string;
  tracks?: Track[];
  children?: ReactNode;
}) {
  const empty = tracks && tracks.length === 0 && !children;
  if (empty) return null;

  return (
    <section className="space-y-3">
      <div className="flex items-end justify-between gap-3">
        {genreId ? (
          <Link
            to="/genre/$genre"
            params={{ genre: genreId }}
            className="group inline-flex items-center gap-1 text-foreground"
          >
            <h2 className="font-display text-lg font-medium tracking-tight sm:text-xl">
              {title}
            </h2>
            <ChevronRight className="size-5 text-muted-foreground transition-transform duration-150 group-hover:translate-x-0.5" />
          </Link>
        ) : (
          <h2 className="font-display text-lg font-medium tracking-tight sm:text-xl">
            {title}
          </h2>
        )}
      </div>
      {tracks ? (
        <div className="flex gap-4 overflow-x-auto pb-1 no-scrollbar">
          {tracks.map((track, i) => (
            <TrackCard key={track.id} track={track} index={i} queue={tracks} />
          ))}
        </div>
      ) : (
        children
      )}
    </section>
  );
}
