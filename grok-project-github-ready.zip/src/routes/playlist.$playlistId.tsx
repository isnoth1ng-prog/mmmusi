import { createFileRoute, notFound } from "@tanstack/react-router";
import { Play } from "lucide-react";
import { Cover } from "@/components/cover";
import { EmptyState } from "@/components/empty-state";
import { TrackList } from "@/components/track-row";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { getPlaylist } from "@/lib/music/functions";
import { usePlayer } from "@/lib/player-store";

export const Route = createFileRoute("/playlist/$playlistId")({
  loader: async ({ params }) => {
    const playlist = await getPlaylist({ data: { id: params.playlistId } });
    if (!playlist) throw notFound();
    return { playlist };
  },
  pendingComponent: PlaylistPending,
  component: PlaylistPage,
});

function PlaylistPage() {
  const { playlist } = Route.useLoaderData();
  const playList = usePlayer((s) => s.playList);

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-8">
      <header className="flex flex-col gap-5 sm:flex-row sm:items-end">
        <Cover
          src={playlist.artwork}
          alt=""
          className="aspect-square w-full max-w-48 rounded-xl sm:w-48"
          sizes="192px"
        />
        <div className="min-w-0">
          <p className="text-sm text-muted-foreground">Подборка</p>
          <h1 className="mt-1 font-display text-3xl font-medium tracking-tight">
            {playlist.name}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {playlist.artist}
            {playlist.trackCount ? ` · ${playlist.trackCount} треков` : ""}
          </p>
          {playlist.tracks.length > 0 ? (
            <Button className="mt-4" onClick={() => playList(playlist.tracks, 0)}>
              <Play className="size-4 fill-current translate-x-px" />
              Слушать
            </Button>
          ) : null}
        </div>
      </header>
      {playlist.tracks.length === 0 ? (
        <EmptyState
          title="Треки недоступны"
          description="Эта подборка сейчас без воспроизводимых композиций."
        />
      ) : (
        <TrackList tracks={playlist.tracks} />
      )}
    </div>
  );
}

function PlaylistPending() {
  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-4">
      <Skeleton className="h-48 w-48 rounded-xl" />
      <Skeleton className="h-10 w-64 rounded-lg" />
    </div>
  );
}
