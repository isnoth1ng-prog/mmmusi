import { createFileRoute } from "@tanstack/react-router";

async function redirectToStream({ params }: { params: { trackId: string } }) {
  const { resolveStreamUrl } = await import("@/lib/music/audius.server");
  const url = await resolveStreamUrl(params.trackId);
  return new Response(null, {
    status: 302,
    headers: {
      Location: url,
      "Cache-Control": "no-store",
    },
  });
}

export const Route = createFileRoute("/api/stream/$trackId")({
  server: {
    handlers: {
      GET: redirectToStream,
      HEAD: redirectToStream,
    },
  },
});
