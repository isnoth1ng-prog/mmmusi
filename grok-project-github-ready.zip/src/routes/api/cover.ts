import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/cover")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const raw = new URL(request.url).searchParams.get("u") ?? "";
        const { fetchArtwork } = await import("@/lib/music/artwork.server");
        return fetchArtwork(raw);
      },
    },
  },
});
