import { createFileRoute, Link } from "@tanstack/react-router";
import { EmptyState } from "@/components/empty-state";
import { TrackList } from "@/components/track-row";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useHydrated } from "@/hooks/use-hydrated";
import { useLikes } from "@/lib/likes-store";

export const Route = createFileRoute("/liked")({
  component: LikedPage,
});

function LikedPage() {
  const hydrated = useHydrated();
  const tracks = useLikes((s) =>
    s.ids.map((id) => s.byId[id]).filter((t): t is NonNullable<typeof t> => Boolean(t)),
  );

  if (!hydrated) {
    return (
      <div className="mx-auto flex max-w-3xl flex-col gap-4">
        <Skeleton className="h-10 w-48 rounded-lg" />
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-16 w-full rounded-xl" />
        ))}
      </div>
    );
  }

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-6">
      <header>
        <h1 className="font-display text-3xl font-medium tracking-tight">Любимое</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {tracks.length
            ? `${tracks.length} ${tracksWord(tracks.length)} — хранятся на этом устройстве`
            : "Треки, отмеченные сердцем"}
        </p>
      </header>
      {tracks.length === 0 ? (
        <EmptyState
          title="Пока пусто"
          description="Нажмите сердце на треке — и он появится здесь. Убрать можно тем же сердцем."
          action={
            <Button asChild>
              <Link to="/">Смотреть каталог</Link>
            </Button>
          }
        />
      ) : (
        <TrackList tracks={tracks} />
      )}
    </div>
  );
}

function tracksWord(n: number) {
  const m = n % 100;
  const d = n % 10;
  if (m > 10 && m < 20) return "треков";
  if (d === 1) return "трек";
  if (d >= 2 && d <= 4) return "трека";
  return "треков";
}
