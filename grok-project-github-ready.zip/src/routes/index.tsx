import { createFileRoute, Link } from "@tanstack/react-router";
import { FeaturedHero } from "@/components/featured-hero";
import { PlaylistCard } from "@/components/playlist-card";
import { SectionRail } from "@/components/section-rail";
import { Skeleton } from "@/components/ui/skeleton";
import { getHomeFeed } from "@/lib/music/functions";
import { GENRES } from "@/lib/music/types";

export const Route = createFileRoute("/")({
  loader: () => getHomeFeed(),
  pendingComponent: HomePending,
  component: Home,
});

function Home() {
  const feed = Route.useLoaderData();

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-10">
      <header className="flex flex-col gap-2">
        <p className="text-sm text-muted-foreground">Музыкальный сервис</p>
        <h1 className="font-display text-3xl font-medium tracking-tight sm:text-4xl">
          Волна
        </h1>
        <p className="max-w-xl text-sm text-muted-foreground sm:text-base">
          Полные треки с настоящими именами авторов — без вырезанных слов и
          радио-версий.
        </p>
      </header>

      {feed.trending.length === 0 && feed.underground.length === 0 ? (
        <p className="rounded-2xl bg-card px-5 py-8 text-sm text-muted-foreground shadow-[var(--shadow-border)]">
          Каталог сейчас недоступен. Обновите страницу через минуту.
        </p>
      ) : (
        <FeaturedHero tracks={feed.trending} />
      )}

      <div className="flex gap-2 overflow-x-auto no-scrollbar">
        {GENRES.map((g) => (
          <Link
            key={g.id}
            to="/genre/$genre"
            params={{ genre: g.id }}
            className="h-9 shrink-0 rounded-full bg-secondary px-4 text-sm leading-9 text-secondary-foreground hover:bg-accent"
          >
            {g.label}
          </Link>
        ))}
      </div>

      <SectionRail title="В тренде" tracks={feed.trending} />
      <SectionRail title="Новые имена" tracks={feed.underground} />

      {feed.playlists.length > 0 ? (
        <SectionRail title="Подборки">
          <div className="flex gap-4 overflow-x-auto pb-1 no-scrollbar">
            {feed.playlists.map((p) => (
              <PlaylistCard key={p.id} playlist={p} />
            ))}
          </div>
        </SectionRail>
      ) : null}

      {feed.genres.map((g) => (
        <SectionRail key={g.id} title={g.label} genreId={g.id} tracks={g.tracks} />
      ))}
    </div>
  );
}

function HomePending() {
  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-8">
      <Skeleton className="h-10 w-48 rounded-lg" />
      <Skeleton className="h-56 w-full rounded-2xl" />
      <div className="flex gap-4">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-48 w-36 shrink-0 rounded-xl" />
        ))}
      </div>
    </div>
  );
}
