import { createFileRoute, useNavigate, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { EmptyState } from "@/components/empty-state";
import { SearchBox } from "@/components/search-box";
import { TrackList } from "@/components/track-row";
import { Skeleton } from "@/components/ui/skeleton";
import { searchTracks } from "@/lib/music/functions";

export const Route = createFileRoute("/search")({
  validateSearch: (search: Record<string, unknown>) => ({
    q: typeof search.q === "string" ? search.q : "",
  }),
  loaderDeps: ({ search }) => ({ q: search.q }),
  loader: async ({ deps }) => {
    const q = deps.q.trim();
    if (q.length < 1) return { tracks: [], q };
    return { tracks: await searchTracks({ data: { query: q, limit: 30 } }), q };
  },
  component: SearchPage,
});

function SearchPage() {
  const { tracks, q } = Route.useLoaderData();
  const navigate = useNavigate({ from: "/search" });
  const loading = useRouterState({ select: (s) => s.isLoading });
  const [value, setValue] = useState(q);

  useEffect(() => {
    setValue(q);
  }, [q]);

  useEffect(() => {
    const handle = window.setTimeout(() => {
      if (value === q) return;
      void navigate({ search: { q: value }, replace: true });
    }, 380);
    return () => window.clearTimeout(handle);
  }, [value, q, navigate]);

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-6">
      <header className="space-y-3">
        <h1 className="font-display text-3xl font-medium tracking-tight">Поиск</h1>
        <SearchBox value={value} onValueChange={setValue} autoFocus />
      </header>

      {loading && q.trim() ? (
        <div className="flex flex-col gap-2">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-16 w-full rounded-xl" />
          ))}
        </div>
      ) : !q.trim() ? (
        <EmptyState
          title="Найдите трек"
          description="Введите название композиции или имя исполнителя — каталог отдаёт оригиналы без цензуры."
        />
      ) : tracks.length === 0 ? (
        <EmptyState
          title="Ничего не нашлось"
          description={`По запросу «${q}» нет доступных треков. Попробуйте другое написание.`}
        />
      ) : (
        <div>
          <p className="mb-3 text-sm text-muted-foreground">{tracks.length} треков</p>
          <TrackList tracks={tracks} showPlays />
        </div>
      )}
    </div>
  );
}
