import { createFileRoute, notFound } from "@tanstack/react-router";
import { TrackList } from "@/components/track-row";
import { EmptyState } from "@/components/empty-state";
import { Skeleton } from "@/components/ui/skeleton";
import { getGenreTracks } from "@/lib/music/functions";
import { genreById } from "@/lib/music/types";

export const Route = createFileRoute("/genre/$genre")({
  loader: async ({ params }) => {
    const meta = genreById(params.genre);
    if (!meta) throw notFound();
    const tracks = await getGenreTracks({ data: { genre: params.genre } });
    return { meta, tracks };
  },
  pendingComponent: GenrePending,
  component: GenrePage,
});

function GenrePage() {
  const { meta, tracks } = Route.useLoaderData();
  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-6">
      <header>
        <p className="text-sm text-muted-foreground">Жанр</p>
        <h1 className="font-display text-3xl font-medium tracking-tight">{meta.label}</h1>
      </header>
      {tracks.length === 0 ? (
        <EmptyState
          title="Пока тихо"
          description="В этом жанре сейчас нет доступных треков."
        />
      ) : (
        <TrackList tracks={tracks} showPlays />
      )}
    </div>
  );
}

function GenrePending() {
  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-4">
      <Skeleton className="h-10 w-40 rounded-lg" />
      {Array.from({ length: 8 }).map((_, i) => (
        <Skeleton key={i} className="h-16 w-full rounded-xl" />
      ))}
    </div>
  );
}
